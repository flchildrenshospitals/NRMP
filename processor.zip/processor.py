"""
Integrated FDOT document processor with smart slicing for large files.
Uses pdfplumber for everything - no Textract complexity.
"""

# ============================================================================
# IMPORTS AND DEPENDENCIES
# ============================================================================
# Core Python libraries for file operations, memory management, and utilities
import os
import gc
import json
import time
from pathlib import Path
from dataclasses import dataclass
from typing import List, Dict, Any, Optional
import hashlib
import re
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing
import psutil

# External libraries for PDF processing, ML, and data manipulation
import torch
import pdfplumber
try:
    from pypdf import PdfReader, PdfWriter
except ImportError:
    from PyPDF2 import PdfReader, PdfWriter
from langchain.text_splitter import RecursiveCharacterTextSplitter
from tqdm import tqdm
import pandas as pd

# ============================================================================
# DYNAMIC IMPORT CONFIGURATION
# ============================================================================
# Handle import path dynamically to support different execution contexts
import sys
from pathlib import Path

# Add the backend directory to Python path for imports
backend_path = Path(__file__).parent.parent.parent
if str(backend_path) not in sys.path:
    sys.path.insert(0, str(backend_path))

# ============================================================================
# APPLICATION IMPORTS WITH FALLBACK CONFIGURATION
# ============================================================================
# Try to import application-specific modules, fall back to standalone config
try:
    from app.core.config import Paths, Settings
    from app.utils.pdf_manager import pdf_manager
    MINIO_AVAILABLE = True
except ImportError:
    # ========================================================================
    # FALLBACK CONFIGURATION
    # ========================================================================
    # Define paths and settings directly when application imports fail
    print("⚠️  Could not import config module, using fallback paths")
    
    def get_project_root():
        current_path = Path(__file__).resolve()
        
        for parent in [current_path] + list(current_path.parents):
            if any((parent / indicator).exists() for indicator in ['.git', 'pyproject.toml', 'README.md', 'requirements.txt']):
                return parent
        
        # If we can't find project root indicators, go up 4 levels from backend/app/services/processor.py
        return current_path.parent.parent.parent.parent
    
    PROJECT_ROOT = get_project_root()
    
    class Paths:
        RAW_PDFS = PROJECT_ROOT / "data" / "raw_pdfs"
        PROCESSED_CHUNKS = PROJECT_ROOT / "data" / "processed" / "chunks"
        
        @classmethod
        def get_output_paths(cls, filename):
            return {
                "chunks": cls.PROCESSED_CHUNKS / f"{filename}_chunks.json",
                "stats": cls.PROCESSED_CHUNKS / f"{filename}_processing_stats.json"
            }
    
    class Settings:
        DEFAULT_OUTPUT_FILENAME = "integrated_fdot"
        LARGE_FILE_THRESHOLD_MB = 50
        LARGE_FILE_THRESHOLD_PAGES = 5000
    
    # Fallback for when services are not available
    MINIO_AVAILABLE = False
    OPENSEARCH_AVAILABLE = False
    pdf_manager = None

# ============================================================================
# OPTIONAL FEATURE IMPORTS
# ============================================================================
# OCR capabilities - gracefully degrade if not available
try:
    import pytesseract
    from PIL import Image
    OCR_AVAILABLE = True
except ImportError:
    OCR_AVAILABLE = False
    print("⚠️  OCR libraries not available - will skip image text extraction")

# ============================================================================
# DATA STRUCTURES AND MODELS
# ============================================================================

class SemanticAwareTextSplitter(RecursiveCharacterTextSplitter):
    """Enhanced text splitter that respects FDOT document structure and section boundaries.
    
    This splitter extends LangChain's RecursiveCharacterTextSplitter to provide:
    - Section-aware splitting using FDOT document patterns
    - Semantic boundary preservation
    - Hierarchical fallback for content within sections
    - Enhanced metadata about section structure
    """
    
    def __init__(self, section_patterns: List[str], detect_section_header, smart_overlap_calculator=None, separators=None, **kwargs):
        """Initialize the semantic-aware text splitter.

        Args:
            section_patterns: List of regex patterns for detecting section headers
            detect_section_header: Function to detect section headers in text
            smart_overlap_calculator: Function for calculating intelligent overlap between chunks
            separators: List of separators to use for splitting (passed to parent)
            **kwargs: Arguments passed to parent RecursiveCharacterTextSplitter
        """
        # Add separators to kwargs if provided
        if separators is not None:
            kwargs['separators'] = separators

        super().__init__(**kwargs)
        self.section_patterns = section_patterns
        self.detect_section_header = detect_section_header
        self.smart_overlap_calculator = smart_overlap_calculator
        self.base_chunk_size = self._chunk_size  # Store original chunk size for adaptive calculations
        self.base_chunk_overlap = self._chunk_overlap  # Store original overlap for smart calculations
    
    def split_text(self, text: str) -> List[str]:
        """Split text with semantic awareness and table preservation.
        
        Strategy:
        1. Detect and preserve table boundaries first
        2. Identify section boundaries using FDOT patterns  
        3. Split by sections while respecting table integrity
        4. Apply hierarchical splitting within sections if needed
        5. Preserve both section and table integrity
        
        Args:
            text: Input text to split
            
        Returns:
            List of text chunks respecting semantic and table boundaries
        """
        if not text.strip():
            return []
        
        # Step 1: Check for tables and use table-aware processing if needed
        table_info = self._detect_and_extract_tables(text)
        
        if table_info['has_tables']:
            # Delegate to adaptive method for table handling
            return self.split_text_adaptively(text)
        
        # Step 2: No tables - use standard semantic processing
        sections = self._split_by_sections(text)
        
        # Step 3: Process each section, applying hierarchical splitting if needed
        all_chunks = []
        overall_content_type = 'general'
        
        for section in sections:
            section_chunks = self._process_section(section)
            all_chunks.extend(section_chunks)
            
            # Track content type for smart overlap
            section_analysis = self._analyze_section_content(section['content'])
            if section_analysis['content_type'] != 'general':
                overall_content_type = section_analysis['content_type']
        
        # Step 4: Apply smart overlap between chunks if available
        if self.smart_overlap_calculator and len(all_chunks) > 1:
            all_chunks = self._apply_smart_overlap(all_chunks, overall_content_type)
        
        return all_chunks
    
    def _apply_smart_overlap(self, chunks: List[str], content_type: str = 'general') -> List[str]:
        """Apply intelligent overlap between chunks based on semantic boundaries.
        
        Args:
            chunks: List of text chunks to apply smart overlap to
            content_type: Type of content for adaptive overlap strategy
            
        Returns:
            List of chunks with intelligent overlap applied
        """
        if not chunks or len(chunks) <= 1 or not self.smart_overlap_calculator:
            return chunks
        
        smart_chunks = []
        
        for i in range(len(chunks)):
            current_chunk = chunks[i]
            
            if i == 0:
                # First chunk - no overlap needed
                smart_chunks.append(current_chunk)
            else:
                # Calculate smart overlap with previous chunk
                prev_chunk = chunks[i-1]
                overlap_info = self.smart_overlap_calculator(prev_chunk, current_chunk, content_type)
                
                # Apply the calculated overlap
                overlap_text = overlap_info.get('text', '')
                
                if overlap_text:
                    # Prepend the smart overlap to current chunk
                    enhanced_chunk = f"{overlap_text}\n{current_chunk}".strip()
                    smart_chunks.append(enhanced_chunk)
                else:
                    # Fallback to original chunk if overlap calculation failed
                    smart_chunks.append(current_chunk)
        
        return smart_chunks
    
    def split_text_adaptively(self, text: str) -> List[str]:
        """Split text with semantic awareness, adaptive sizing, and table integrity preservation.
        
        This method combines multiple chunking strategies for optimal results:
        1. Table-aware chunking for content with tables
        2. Semantic boundary detection for section structure
        3. Adaptive sizing based on content characteristics  
        4. Smart overlap for context preservation
        
        Args:
            text: Input text to split adaptively
            
        Returns:
            List of optimally-chunked text with preserved table integrity
        """
        if not text.strip():
            return []
        
        # Step 1: Check if text contains tables and use table-aware processing if needed
        table_info = self._detect_and_extract_tables(text)
        
        if table_info['has_tables']:
            # Use table-aware chunking as primary strategy
            table_chunks = self._create_table_aware_chunks(text, self._chunk_size)
            
            if table_chunks:
                # Apply semantic processing to non-table chunks if needed
                enhanced_chunks = []
                overall_content_type = 'table_heavy'
                
                for chunk in table_chunks:
                    # Check if this chunk contains tables
                    chunk_table_info = self._detect_and_extract_tables(chunk)
                    
                    if chunk_table_info['has_tables']:
                        # Table chunk - keep as-is (already atomic)
                        enhanced_chunks.append(chunk)
                    else:
                        # Non-table chunk - apply semantic processing if it's large
                        if len(chunk) > self._chunk_size * 1.2:
                            # Large non-table chunk - apply semantic splitting
                            sections = self._split_by_sections(chunk)
                            for section in sections:
                                section_chunks = self._process_section_adaptively(section)
                                enhanced_chunks.extend(section_chunks)
                        else:
                            # Reasonable size - keep as-is
                            enhanced_chunks.append(chunk)
                
                # Apply smart overlap between all chunks
                if self.smart_overlap_calculator and len(enhanced_chunks) > 1:
                    enhanced_chunks = self._apply_smart_overlap(enhanced_chunks, overall_content_type)
                
                return enhanced_chunks
        
        # Step 2: No tables detected - use standard semantic + adaptive processing
        sections = self._split_by_sections(text)
        
        # Step 3: Process each section with adaptive sizing
        all_chunks = []
        overall_content_type = 'general'
        
        for section in sections:
            section_chunks = self._process_section_adaptively(section)
            all_chunks.extend(section_chunks)
            
            # Track the most common content type for overlap calculation
            section_analysis = self._analyze_section_content(section['content'])
            if section_analysis['content_type'] != 'general':
                overall_content_type = section_analysis['content_type']
        
        # Step 4: Apply smart overlap between all chunks
        if self.smart_overlap_calculator and len(all_chunks) > 1:
            all_chunks = self._apply_smart_overlap(all_chunks, overall_content_type)
        
        return all_chunks
    
    def _process_section_adaptively(self, section: Dict[str, Any]) -> List[str]:
        """Process a section using adaptive sizing based on content analysis.
        
        Args:
            section: Section dictionary with content and metadata
            
        Returns:
            List of adaptively-sized chunks for this section
        """
        content = section['content']
        header = section.get('header')
        
        # Analyze content characteristics for this section
        analysis = self._analyze_section_content(content)
        optimal_size = analysis['optimal_chunk_size']
        
        # Temporarily adjust chunk size for this section
        original_size = self._chunk_size
        self._chunk_size = optimal_size
        
        try:
            # Check if section fits within optimal size
            if len(content) <= optimal_size:
                return [content]
            
            # Section needs splitting - apply adaptive hierarchical splitting
            if header:
                # Keep header with content, use adaptive splitting for rest
                header_line = content.split('\n')[0]
                remaining_content = '\n'.join(content.split('\n')[1:])
                
                # Split remaining content using adaptive size
                content_chunks = super().split_text(remaining_content)
                
                # Ensure header stays with first chunk
                if content_chunks:
                    content_chunks[0] = f"{header_line}\n{content_chunks[0]}"
                else:
                    content_chunks = [header_line]
                
                return content_chunks
            else:
                # No header - use adaptive hierarchical splitting
                return super().split_text(content)
        
        finally:
            # Restore original chunk size
            self._chunk_size = original_size
    
    def _analyze_section_content(self, content: str) -> Dict[str, Any]:
        """Analyze section content to determine optimal chunk size.
        
        This is a simplified content analysis specifically for the splitter.
        The main processor has a more comprehensive analysis method.
        
        Args:
            content: Section content to analyze
            
        Returns:
            Dictionary with analysis results including optimal_chunk_size
        """
        analysis = {
            'content_type': 'general',
            'optimal_chunk_size': self.base_chunk_size
        }
        
        if not content.strip():
            return analysis
        
        # Quick content type detection
        text_lower = content.lower()
        
        # Technical content indicators
        if any(indicator in text_lower for indicator in ['shall', 'specification', 'minimum', 'maximum', 'astm', 'aashto']):
            analysis['content_type'] = 'technical'
            analysis['optimal_chunk_size'] = int(self.base_chunk_size * 0.8)  # 20% smaller for dense technical content
        
        # List/procedural content
        elif len(re.findall(r'^\s*[\da-z]\)\s+|^\s*\d+\.\s+', content, re.MULTILINE)) > 3:
            analysis['content_type'] = 'procedural'
            analysis['optimal_chunk_size'] = int(self.base_chunk_size * 0.6)  # 40% smaller to keep lists intact
        
        # Narrative content
        elif len(re.findall(r'\b(the|this|that|when|where|how)\s+', content, re.IGNORECASE)) > 10:
            analysis['content_type'] = 'narrative'
            analysis['optimal_chunk_size'] = int(self.base_chunk_size * 1.2)  # 20% larger for flowing text
        
        # Table content
        elif '[TABLE' in content and '[END TABLE' in content:
            analysis['content_type'] = 'table_heavy'
            analysis['optimal_chunk_size'] = int(self.base_chunk_size * 1.4)  # 40% larger to accommodate tables
        
        return analysis
    
    def _detect_and_extract_tables(self, text: str) -> Dict[str, Any]:
        """Detect and extract table boundaries for table-aware chunking in the splitter."""
        table_info = {
            'tables': [],
            'table_boundaries': [],
            'text_without_tables': text,
            'has_tables': False
        }
        
        # Pattern to match our table markers: [TABLE X] ... [END TABLE X]
        table_pattern = r'\[TABLE\s+(\d+)[^\]]*\](.*?)\[END\s+TABLE\s+\1\]'
        
        matches = list(re.finditer(table_pattern, text, re.DOTALL | re.IGNORECASE))
        
        if matches:
            table_info['has_tables'] = True
            
            for match in matches:
                table_number = match.group(1)
                table_content = match.group(0)  # Full table including markers
                table_text_only = match.group(2).strip()  # Content between markers
                
                start_pos = match.start()
                end_pos = match.end()
                
                # Analyze table characteristics
                table_data = {
                    'table_number': table_number,
                    'full_content': table_content,
                    'text_content': table_text_only,
                    'start_position': start_pos,
                    'end_position': end_pos,
                    'length': len(table_content),
                    'row_count': len(table_text_only.split('\n')) if table_text_only else 0,
                    'is_large': len(table_content) > 800,  # Consider tables > 800 chars as large
                    'preceding_context': '',  # Will be filled when analyzing placement
                    'following_context': ''   # Will be filled when analyzing placement
                }
                
                table_info['tables'].append(table_data)
                table_info['table_boundaries'].append((start_pos, end_pos))
        
        return table_info

    def _find_table_context(self, text: str, table_data: Dict, context_window: int = 200) -> Dict[str, str]:
        """Find contextual text around tables for better placement decisions."""
        start_pos = table_data['start_position']
        end_pos = table_data['end_position']
        
        # Extract preceding context
        context_start = max(0, start_pos - context_window)
        preceding_text = text[context_start:start_pos].strip()
        
        # Extract following context  
        context_end = min(len(text), end_pos + context_window)
        following_text = text[end_pos:context_end].strip()
        
        # Clean up context - find sentence boundaries
        if preceding_text:
            # Find last complete sentence before table
            sentences = re.split(r'\.(\s+)', preceding_text)
            if len(sentences) > 1:
                preceding_text = '.'.join(sentences[:-1]) + '.'
        
        if following_text:
            # Find first complete sentence after table
            first_sentence = re.split(r'\.(\s+)', following_text)
            if first_sentence:
                following_text = first_sentence[0] + '.' if not first_sentence[0].endswith('.') else first_sentence[0]
        
        return {
            'preceding_context': preceding_text,
            'following_context': following_text
        }

    def _create_table_aware_chunks(self, text: str, chunk_size: int) -> List[str]:
        """Create chunks that respect table boundaries and maintain table integrity."""
        # Step 1: Detect and analyze tables
        table_info = self._detect_and_extract_tables(text)
        
        if not table_info['has_tables']:
            # No tables - use standard processing
            return []  # Let standard splitter handle this
        
        # Step 2: Analyze table contexts
        for table_data in table_info['tables']:
            context = self._find_table_context(text, table_data)
            table_data.update(context)
        
        # Step 3: Create table-aware chunks
        chunks = []
        current_pos = 0
        
        for i, table_data in enumerate(table_info['tables']):
            table_start = table_data['start_position']
            table_end = table_data['end_position']
            table_content = table_data['full_content']
            
            # Get text before this table
            pre_table_text = text[current_pos:table_start].strip()
            
            # Decide how to handle the table placement
            table_with_context = self._determine_table_placement(
                pre_table_text, 
                table_data, 
                chunk_size
            )
            
            # Add pre-table chunks if needed
            if table_with_context['pre_table_chunk']:
                chunks.append(table_with_context['pre_table_chunk'])
            
            # Add table chunk
            chunks.append(table_with_context['table_chunk'])
            
            # Update position
            current_pos = table_end
        
        # Handle remaining text after last table
        remaining_text = text[current_pos:].strip()
        if remaining_text:
            chunks.append(remaining_text)
        
        return chunks

    def _determine_table_placement(self, pre_table_text: str, table_data: Dict, chunk_size: int) -> Dict[str, str]:
        """Determine optimal placement strategy for a table with its context."""
        table_content = table_data['full_content']
        table_length = table_data['length']
        preceding_context = table_data['preceding_context']
        
        # Calculate combined size
        context_size = len(preceding_context) if preceding_context else 0
        combined_size = context_size + table_length
        
        # Strategy 1: Table with immediate context fits in one chunk
        if combined_size <= chunk_size * 0.9:  # 90% of chunk size for buffer
            return {
                'pre_table_chunk': pre_table_text[:-len(preceding_context)].strip() if preceding_context and len(pre_table_text) > len(preceding_context) else '',
                'table_chunk': f"{preceding_context}\n{table_content}".strip()
            }
        
        # Strategy 2: Table alone fits in chunk size
        elif table_length <= chunk_size:
            return {
                'pre_table_chunk': pre_table_text,
                'table_chunk': table_content
            }
        
        # Strategy 3: Large table handling - keep atomic
        else:
            # For very large tables, we prioritize table integrity over chunk size
            return {
                'pre_table_chunk': pre_table_text,
                'table_chunk': table_content  # Keep table atomic even if large
            }
    
    def _split_by_sections(self, text: str) -> List[Dict[str, Any]]:
        """Split text into sections based on detected headers.
        
        Returns:
            List of section dictionaries with content and metadata
        """
        lines = text.split('\n')
        sections = []
        current_section = {'header': None, 'content': [], 'start_line': 0}
        
        for i, line in enumerate(lines):
            # Check if this line is a section header
            header = self.detect_section_header(line.strip())
            
            if header and i > 0:  # Don't split on very first line
                # Save the previous section if it has content
                if current_section['content']:
                    current_section['content'] = '\n'.join(current_section['content'])
                    sections.append(current_section)
                
                # Start new section
                current_section = {
                    'header': header,
                    'content': [line],
                    'start_line': i
                }
            else:
                current_section['content'].append(line)
        
        # Add the final section
        if current_section['content']:
            current_section['content'] = '\n'.join(current_section['content'])
            sections.append(current_section)
        
        return sections
    
    def _process_section(self, section: Dict[str, Any]) -> List[str]:
        """Process a single section, applying hierarchical splitting if needed.
        
        Args:
            section: Section dictionary with content and metadata
            
        Returns:
            List of chunks for this section
        """
        content = section['content']
        header = section.get('header')
        
        # Check if section fits within chunk size
        if len(content) <= self._chunk_size:
            return [content]
        
        # Section is too large - apply hierarchical splitting while preserving header
        if header:
            # Keep header with first chunk, use standard splitting for rest
            header_line = content.split('\n')[0]
            remaining_content = '\n'.join(content.split('\n')[1:])
            
            # Split remaining content using parent method
            content_chunks = super().split_text(remaining_content)
            
            # Ensure header stays with first chunk
            if content_chunks:
                content_chunks[0] = f"{header_line}\n{content_chunks[0]}"
            else:
                content_chunks = [header_line]
            
            return content_chunks
        else:
            # No header - use standard hierarchical splitting
            return super().split_text(content)

@dataclass
class EnhancedDocumentChunk:
    """Enhanced document chunk with comprehensive metadata and extracted content.
    
    Attributes:
        content: The text content of the chunk
        metadata: Comprehensive metadata including source, page info, processing details
        chunk_id: Unique identifier for the chunk (MD5 hash)
        page_number: Source page number in the original document
        tables: Extracted table data (only on first chunk of page to avoid duplication)
        section_info: Detected section headers and structural information
    """
    content: str
    metadata: Dict[str, Any]
    chunk_id: str
    page_number: int
    tables: List[Dict] = None
    section_info: Dict = None


# ============================================================================
# MAIN PROCESSOR CLASS
# ============================================================================

class IntegratedFDOTProcessor:
    """Unified FDOT document processor with intelligent processing strategy selection.
    
    This processor automatically chooses between direct processing and slicing based on
    file size and page count. It provides comprehensive content extraction including
    text, tables, images with OCR, and maintains detailed processing statistics.
    
    Key Features:
    - Smart slicing for large files to manage memory usage
    - Direct processing for smaller files for efficiency
    - Comprehensive content extraction (text, tables, OCR)
    - Robust error handling with detailed statistics
    - Parallel processing support with memory management
    """
    
    def __init__(self, chunk_size: int = 1000, chunking_strategy: str = "semantic_aware", large_file_threshold_mb: int = 50, large_file_threshold_pages: int = 500):
        """
        Initialize the FDOT processor with configurable chunking and processing thresholds.

        Args:
            chunk_size: Target size for text chunks in characters (default: 1000)
            chunking_strategy: Strategy for chunking - "semantic_aware", "section_aware", or "fixed_size" (default: "semantic_aware")
            large_file_threshold_mb: File size threshold in MB for switching to slicing (default: 50)
            large_file_threshold_pages: Page count threshold for switching to slicing (default: 500)
        """
        # ====================================================================
        # STRATEGY CONFIGURATION
        # ====================================================================
        self.chunking_strategy = chunking_strategy

        # Configure parameters based on strategy
        if chunking_strategy == "semantic_aware":
            self._chunk_size = 1000
            self._chunk_overlap = 200
            self._separators = [
                "\n\n\n",  # Chapter/major section breaks
                "\n\n",    # Paragraph breaks
                "\n",      # Line breaks
                ". ",      # Sentence boundaries (with space to avoid abbreviations!)
                "; ",      # Clause boundaries for complex technical sentences
                "",        # Fallback character-level splitting
            ]
        elif chunking_strategy == "section_aware":
            self._chunk_size = 1500
            self._chunk_overlap = 300
            self._separators = [
                "\n\n\n",  # Chapter/major section breaks (prioritize)
                "\n\n",    # Paragraph breaks
                "\n",      # Line breaks
                "",        # Fallback character-level splitting
            ]
        elif chunking_strategy == "fixed_size":
            self._chunk_size = 1200
            self._chunk_overlap = 200
            self._separators = [
                "\n",      # Line breaks only
                "",        # Fallback character-level splitting
            ]
        else:
            # Default to semantic_aware
            self._chunk_size = 1000
            self._chunk_overlap = 200
            self._separators = ["\n\n\n", "\n\n", "\n", ". ", "; ", ""]

        # Override with explicit chunk_size if provided
        if chunk_size != 1000:
            self._chunk_size = chunk_size

        # ====================================================================
        # CHUNKING CONFIGURATION
        # ====================================================================
        # Configure the text splitter with strategy-specific parameters
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=self._chunk_size,
            chunk_overlap=self._chunk_overlap,
            length_function=len,
            separators=self._separators,
            keep_separator=True
        )

        # ====================================================================
        # SEMANTIC-AWARE CHUNKING ENHANCEMENT
        # ====================================================================
        # Create enhanced splitter that respects document structure
        self.semantic_splitter = self._create_semantic_splitter(self._chunk_size, self._chunk_overlap, self._separators)
        
        # ====================================================================
        # PROCESSING STRATEGY THRESHOLDS
        # ====================================================================
        # Thresholds for determining when to use slicing vs direct processing
        self.large_file_threshold_mb = large_file_threshold_mb
        self.large_file_threshold_pages = large_file_threshold_pages
        
        # ====================================================================
        # PROCESSING STATISTICS TRACKING
        # ====================================================================
        # Comprehensive statistics for monitoring extraction quality and performance
        self.extraction_stats = {
            'text_extraction_failures': 0,
            'table_extraction_failures': 0,
            'ocr_extraction_failures': 0,
            'total_pages_processed': 0,
            'total_text_extracted': 0,
            'direct_processing_documents': 0,
            'sliced_processing_documents': 0,
            'total_tables_found': 0
        }

    # ========================================================================
    # ADAPTIVE AND SEMANTIC-AWARE CHUNKING IMPLEMENTATION
    # ========================================================================
    
    def _create_semantic_splitter(self, chunk_size: int, chunk_overlap: int, separators: List[str]):
        """Create a semantic-aware text splitter that respects document structure."""
        return SemanticAwareTextSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            length_function=len,
            separators=separators,
            section_patterns=self._get_section_patterns(),
            detect_section_header=self._detect_section_header,
            smart_overlap_calculator=self._calculate_smart_overlap
        )
    
    def _get_section_patterns(self) -> List[str]:
        """Get regex patterns for detecting section headers in FDOT documents."""
        return [
            r'^\d+[\.\-]\d*[\.\-]*\d*\s+[A-Z]',  # e.g., "1.1.1 GENERAL"
            r'^[A-Z][A-Z\s]{5,50}$',              # e.g., "GENERAL REQUIREMENTS"
            r'^\d+\s+[A-Z]',                      # e.g., "100 Construction Equipment"
            r'^[A-Z]+\s*\d+[\.\-]\d*',           # e.g., "SECTION 1.1"
            r'^\d+\.\d+\s+[A-Z]',                 # e.g., "10.1 MATERIALS"
        ]
    
    def _split_text_semantically(self, text: str) -> List[str]:
        """Split text using semantic awareness of document structure.
        
        This method:
        1. Identifies section headers as primary split points
        2. Creates chunks that respect section boundaries
        3. Falls back to hierarchical splitting within sections
        4. Ensures semantic coherence across chunk boundaries
        
        Args:
            text: Text content to split
            
        Returns:
            List of semantically-aware text chunks
        """
        if not text.strip():
            return []
        
        # Use the semantic splitter with adaptive sizing for enhanced chunking
        return self.semantic_splitter.split_text_adaptively(text)

    def _analyze_content_characteristics(self, text: str) -> Dict[str, Any]:
        """Analyze content to determine optimal chunking strategy.
        
        This method analyzes various content characteristics to inform
        adaptive chunk sizing decisions:
        
        - Content density (technical vs narrative)
        - Document structure patterns
        - Information density
        - List vs paragraph formatting
        - Technical specification indicators
        
        Args:
            text: Text content to analyze
            
        Returns:
            Dictionary with content analysis results and sizing recommendations
        """
        analysis = {
            'content_type': 'general',
            'density_score': 0.5,
            'optimal_chunk_size': 1000,
            'structure_indicators': [],
            'technical_density': 0.0,
            'list_density': 0.0,
            'narrative_density': 0.0
        }
        
        if not text.strip():
            return analysis
        
        lines = text.split('\n')
        total_lines = len(lines)
        
        # ================================================================
        # CONTENT TYPE DETECTION
        # ================================================================
        
        # Technical specification indicators
        technical_patterns = [
            r'\d+\.\d+\s*(mm|cm|m|ft|in|psi|mpa|%)',  # Measurements/specifications
            r'shall\s+(be|not|comply|meet)',           # Specification language
            r'(minimum|maximum|tolerance|specification)', # Technical terms
            r'\b(ASTM|AASHTO|ACI|FDOT)\s*[-\s]*\w+',   # Standards references
            r'(section|subsection|paragraph)\s+\d+',    # Cross-references
        ]
        
        # List/enumeration indicators  
        list_patterns = [
            r'^\s*[\da-z]\)\s+',    # a) b) c) or 1) 2) 3)
            r'^\s*\d+\.\s+',        # 1. 2. 3.
            r'^\s*[•\-\*]\s+',      # Bullet points
            r'^\s*[IVX]+\.\s+',     # Roman numerals
        ]
        
        # Narrative indicators
        narrative_patterns = [
            r'\b(the|this|that|these|those)\s+\w+',  # Articles and demonstratives
            r'\b(when|where|how|why|what)\s+',       # Question words
            r'\b(because|since|although|however)\s+', # Conjunctions
        ]
        
        # Count pattern matches
        technical_matches = sum(len(re.findall(pattern, text, re.IGNORECASE)) for pattern in technical_patterns)
        list_matches = sum(len(re.findall(pattern, line, re.IGNORECASE)) for line in lines for pattern in list_patterns)
        narrative_matches = sum(len(re.findall(pattern, text, re.IGNORECASE)) for pattern in narrative_patterns)
        
        # Calculate densities
        text_length = len(text)
        analysis['technical_density'] = min(1.0, technical_matches / max(1, text_length / 100))
        analysis['list_density'] = min(1.0, list_matches / max(1, total_lines))
        analysis['narrative_density'] = min(1.0, narrative_matches / max(1, text_length / 100))
        
        # ================================================================
        # CONTENT TYPE CLASSIFICATION
        # ================================================================
        
        if analysis['technical_density'] > 0.3:
            analysis['content_type'] = 'technical_specification'
            analysis['optimal_chunk_size'] = 800  # Smaller for dense technical content
        elif analysis['list_density'] > 0.4:
            analysis['content_type'] = 'procedural_list'
            analysis['optimal_chunk_size'] = 600  # Smaller to keep lists intact
        elif analysis['narrative_density'] > 0.2:
            analysis['content_type'] = 'narrative_description'
            analysis['optimal_chunk_size'] = 1200  # Larger for flowing text
        else:
            analysis['content_type'] = 'general'
            analysis['optimal_chunk_size'] = 1000  # Default size
        
        # ================================================================
        # STRUCTURE ANALYSIS
        # ================================================================
        
        # Check for tables
        if '[TABLE' in text and '][END TABLE' in text:
            analysis['structure_indicators'].append('contains_tables')
            analysis['optimal_chunk_size'] = min(analysis['optimal_chunk_size'], 1400)  # Account for table content
        
        # Check for section headers
        if self._detect_section_header(text):
            analysis['structure_indicators'].append('has_section_header')
        
        # Check for numbered items
        if len(re.findall(r'^\s*\d+[\.\)]\s+', text, re.MULTILINE)) > 3:
            analysis['structure_indicators'].append('numbered_items')
            analysis['optimal_chunk_size'] = min(analysis['optimal_chunk_size'], 900)
        
        # Calculate overall density score
        analysis['density_score'] = (
            analysis['technical_density'] * 0.4 + 
            analysis['list_density'] * 0.3 + 
            analysis['narrative_density'] * 0.3
        )
        
        return analysis

    def _calculate_smart_overlap(self, current_chunk: str, next_chunk: str, content_type: str = 'general') -> Dict[str, Any]:
        """Calculate intelligent overlap between chunks based on semantic boundaries.
        
        This method finds optimal overlap points that:
        - Preserve sentence boundaries  
        - Maintain semantic context
        - Adapt to content type characteristics
        - Ensure logical flow between chunks
        
        Args:
            current_chunk: Text of the current chunk
            next_chunk: Text of the following chunk  
            content_type: Type of content for adaptive overlap strategy
            
        Returns:
            Dictionary with overlap details including size, text, and boundary info
        """
        # ================================================================
        # CONTENT-ADAPTIVE OVERLAP SIZING
        # ================================================================
        base_overlap_ratios = {
            'technical_specification': 0.15,    # 15% - smaller, precise context  
            'procedural_list': 0.10,            # 10% - minimal overlap for list clarity
            'narrative_description': 0.25,      # 25% - larger for context continuity
            'table_heavy': 0.12,                # 12% - moderate for table context
            'general': 0.20                     # 20% - balanced default
        }
        
        overlap_ratio = base_overlap_ratios.get(content_type, 0.20)
        target_overlap_size = int(len(current_chunk) * overlap_ratio)
        
        # ================================================================
        # FIND OPTIMAL OVERLAP BOUNDARIES
        # ================================================================
        
        # Start from the end of current chunk and work backwards to find good boundary
        chunk_end = current_chunk.rstrip()
        
        # Define boundary patterns in order of preference
        boundary_patterns = [
            (r'\.(\s+[A-Z])', 'sentence_boundary'),      # Sentence end followed by capital letter
            (r'\.(\s*\n)', 'sentence_end_newline'),      # Sentence end with newline
            (r';(\s+)', 'clause_boundary'),              # Semicolon boundaries  
            (r'\n\n(\s*)', 'paragraph_boundary'),        # Paragraph breaks
            (r'\n(\s*[A-Z])', 'line_break_capital'),     # Line break followed by capital
            (r'(\s+)', 'word_boundary'),                 # Word boundaries as fallback
        ]
        
        # ================================================================
        # SEARCH FOR OPTIMAL OVERLAP POINT
        # ================================================================
        
        optimal_overlap = {
            'size': min(target_overlap_size, 200),  # Fallback to 200 chars max
            'text': current_chunk[-min(target_overlap_size, 200):],
            'boundary_type': 'character_fallback',
            'boundary_quality': 0.0
        }
        
        # Look for semantic boundaries within reasonable range
        search_start = max(0, len(chunk_end) - int(target_overlap_size * 1.5))
        search_end = max(0, len(chunk_end) - int(target_overlap_size * 0.5))
        search_text = chunk_end[search_start:]
        
        for pattern, boundary_type in boundary_patterns:
            matches = list(re.finditer(pattern, search_text))
            if matches:
                # Find the match closest to our target overlap size
                best_match = None
                best_distance = float('inf')
                
                for match in matches:
                    # Calculate position in original chunk
                    match_pos = search_start + match.start()
                    overlap_from_match = len(chunk_end) - match_pos
                    
                    # Distance from target size
                    distance = abs(overlap_from_match - target_overlap_size)
                    
                    # Prefer matches within reasonable range
                    if search_end <= match_pos <= len(chunk_end) and distance < best_distance:
                        best_distance = distance
                        best_match = match
                        overlap_size = overlap_from_match
                
                if best_match:
                    match_pos = search_start + best_match.start()
                    overlap_text = chunk_end[match_pos:]
                    
                    # Quality score based on boundary type and size appropriateness
                    quality_scores = {
                        'sentence_boundary': 1.0,
                        'sentence_end_newline': 0.9,
                        'paragraph_boundary': 0.8,
                        'clause_boundary': 0.7,
                        'line_break_capital': 0.6,
                        'word_boundary': 0.3
                    }
                    
                    size_quality = 1.0 - (best_distance / target_overlap_size)
                    boundary_quality = quality_scores.get(boundary_type, 0.1)
                    overall_quality = (boundary_quality * 0.7) + (size_quality * 0.3)
                    
                    # Update optimal overlap if this is better
                    if overall_quality > optimal_overlap['boundary_quality']:
                        optimal_overlap = {
                            'size': len(overlap_text),
                            'text': overlap_text,
                            'boundary_type': boundary_type,
                            'boundary_quality': overall_quality
                        }
                    break  # Found good boundary, stop searching
        
        # ================================================================
        # CONTENT-SPECIFIC ADJUSTMENTS
        # ================================================================
        
        # For technical content, ensure we don't cut technical terms
        if content_type == 'technical_specification':
            overlap_text = optimal_overlap['text']
            # Check if we're cutting a technical pattern
            tech_patterns = ['ASTM', 'AASHTO', 'Section', 'Subsection', 'Figure', 'Table']
            for pattern in tech_patterns:
                if pattern.lower() in overlap_text.lower() and not overlap_text.strip().endswith('.'):
                    # Extend overlap to include complete technical reference
                    extended_text = current_chunk[-(optimal_overlap['size'] + 50):]
                    optimal_overlap['text'] = extended_text
                    optimal_overlap['size'] = len(extended_text)
                    break
        
        # For procedural content, align with list item boundaries
        elif content_type == 'procedural_list':
            overlap_text = optimal_overlap['text']
            # Look for numbered item boundaries
            if re.search(r'\d+[\.\)]\s+', overlap_text):
                # Try to start overlap at beginning of numbered item
                match = re.search(r'\n\s*\d+[\.\)]\s+', current_chunk[::-1])
                if match:
                    optimal_overlap['text'] = current_chunk[-match.start():]
                    optimal_overlap['size'] = match.start()
        
        return optimal_overlap

    def _validate_chunk_quality(self, chunk: str, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Comprehensive chunk quality validation and scoring system.
        
        This method evaluates chunks across multiple quality dimensions:
        - Completeness: No truncated sentences or broken references
        - Coherence: Logical flow and semantic integrity
        - Information Density: Appropriate content density
        - Structural Integrity: Tables, lists, and sections preserved
        - Context Sufficiency: Adequate context for understanding
        
        Args:
            chunk: Text content of the chunk
            metadata: Chunk metadata including content type, boundaries, etc.
            
        Returns:
            Dictionary with quality scores, issues found, and recommendations
        """
        quality_report = {
            'overall_score': 0.0,
            'dimensions': {
                'completeness': {'score': 0.0, 'issues': []},
                'coherence': {'score': 0.0, 'issues': []},
                'information_density': {'score': 0.0, 'issues': []},
                'structural_integrity': {'score': 0.0, 'issues': []},
                'context_sufficiency': {'score': 0.0, 'issues': []}
            },
            'recommendations': [],
            'requires_reprocessing': False,
            'quality_class': 'pending'  # excellent, good, acceptable, poor
        }
        
        if not chunk or not chunk.strip():
            quality_report['overall_score'] = 0.0
            quality_report['quality_class'] = 'poor'
            quality_report['requires_reprocessing'] = True
            quality_report['recommendations'].append('Empty or whitespace-only chunk detected')
            return quality_report
        
        # ================================================================
        # COMPLETENESS VALIDATION
        # ================================================================
        completeness_score = 1.0
        completeness_issues = []
        
        # Check for truncated sentences at start
        if chunk.strip()[0].islower() and not chunk.startswith(('i.e.', 'e.g.', 'vs.')):
            completeness_score -= 0.3
            completeness_issues.append('Chunk starts mid-sentence (lowercase beginning)')
        
        # Check for incomplete sentences at end
        last_sentence_endings = ['. ', '.\n', '!', '?', ':]', '[END TABLE']
        if not any(chunk.rstrip().endswith(ending) for ending in last_sentence_endings):
            # Check if it's a valid non-sentence ending (like a heading)
            if not (chunk.rstrip()[-1].isupper() or chunk.rstrip().endswith((')', ']'))):
                completeness_score -= 0.3
                completeness_issues.append('Chunk ends mid-sentence (no terminal punctuation)')
        
        # Check for broken references
        reference_patterns = [
            (r'\b(see|refer to|as shown in|illustrated in)\s+$', 'Broken reference at chunk end'),
            (r'^\s*(above|below|following|previous)\s+\w+', 'Orphaned reference at chunk start'),
            (r'\bTable\s+\d+\s*$', 'Table reference without table content'),
            (r'\bFigure\s+\d+\s*$', 'Figure reference without figure content'),
            (r'\bSection\s+[\d.]+\s*$', 'Section reference at chunk boundary')
        ]
        
        for pattern, issue in reference_patterns:
            if re.search(pattern, chunk, re.IGNORECASE):
                completeness_score -= 0.2
                completeness_issues.append(issue)
        
        quality_report['dimensions']['completeness']['score'] = max(0, completeness_score)
        quality_report['dimensions']['completeness']['issues'] = completeness_issues
        
        # ================================================================
        # COHERENCE VALIDATION
        # ================================================================
        coherence_score = 1.0
        coherence_issues = []
        
        # Check for logical flow indicators
        lines = chunk.strip().split('\n')
        
        # Check if numbered lists are complete
        numbered_items = re.findall(r'^(\d+)[.\)]\s+', chunk, re.MULTILINE)
        if numbered_items:
            numbers = [int(n) for n in numbered_items]
            expected = list(range(min(numbers), max(numbers) + 1))
            if numbers != expected:
                coherence_score -= 0.3
                coherence_issues.append(f'Incomplete numbered list: found {numbers}, expected {expected}')
        
        # Check for orphaned list items
        if re.match(r'^\s*[\da-z][.\)]\s+', chunk.strip()) and len(lines) < 3:
            coherence_score -= 0.2
            coherence_issues.append('Orphaned list item without context')
        
        # Check for sudden topic changes (using section headers)
        if metadata.get('section_header') and len(lines) > 5:
            # If chunk has section header but very little content after
            header_line = next((i for i, line in enumerate(lines) if metadata['section_header'] in line), -1)
            if header_line != -1 and header_line > len(lines) - 3:
                coherence_score -= 0.2
                coherence_issues.append('Section header with insufficient following content')
        
        quality_report['dimensions']['coherence']['score'] = max(0, coherence_score)
        quality_report['dimensions']['coherence']['issues'] = coherence_issues
        
        # ================================================================
        # INFORMATION DENSITY VALIDATION
        # ================================================================
        density_score = 1.0
        density_issues = []
        
        # Calculate various density metrics
        chunk_length = len(chunk)
        word_count = len(chunk.split())
        line_count = len(lines)
        avg_words_per_line = word_count / max(line_count, 1)
        
        # Check for appropriate density based on content type
        content_type = metadata.get('content_type', 'general')
        
        if content_type == 'technical_specification':
            # Technical content should be dense but not overwhelming
            if word_count < 50:
                density_score -= 0.3
                density_issues.append(f'Insufficient content for technical specification ({word_count} words)')
            elif avg_words_per_line > 25:
                density_score -= 0.2
                density_issues.append('Lines too dense for technical content (>25 words/line avg)')
        
        elif content_type == 'procedural_list':
            # Procedural content should have clear, concise items
            if avg_words_per_line > 20:
                density_score -= 0.2
                density_issues.append('Procedural items too verbose (>20 words/line avg)')
        
        elif content_type == 'narrative_description':
            # Narrative should have good flow
            if word_count < 80:
                density_score -= 0.2
                density_issues.append(f'Insufficient narrative content ({word_count} words)')
        
        # Check for chunks that are mostly whitespace
        non_whitespace_ratio = len(chunk.strip()) / max(chunk_length, 1)
        if non_whitespace_ratio < 0.7:
            density_score -= 0.3
            density_issues.append('Excessive whitespace (>30% of chunk)')
        
        quality_report['dimensions']['information_density']['score'] = max(0, density_score)
        quality_report['dimensions']['information_density']['issues'] = density_issues
        
        # ================================================================
        # STRUCTURAL INTEGRITY VALIDATION
        # ================================================================
        integrity_score = 1.0
        integrity_issues = []
        
        # Table integrity checks
        table_starts = len(re.findall(r'\[TABLE\s+\d+', chunk))
        table_ends = len(re.findall(r'\[END\s+TABLE\s+\d+\]', chunk))
        
        if table_starts != table_ends:
            integrity_score -= 0.5
            integrity_issues.append(f'Incomplete table structure: {table_starts} starts, {table_ends} ends')
        
        # Check for broken table references
        if metadata.get('is_table_aware') and not metadata.get('table_integrity_preserved'):
            integrity_score -= 0.4
            integrity_issues.append('Table-aware chunk without integrity guarantee')
        
        # List structure validation
        bullet_items = len(re.findall(r'^\s*[•\-\*]\s+', chunk, re.MULTILINE))
        if bullet_items == 1:
            integrity_score -= 0.2
            integrity_issues.append('Single bullet point without list context')
        
        # Section structure validation
        if metadata.get('section_header'):
            # Check if section header appears multiple times (possible duplication)
            header_count = chunk.count(metadata['section_header'])
            if header_count > 1:
                integrity_score -= 0.2
                integrity_issues.append(f'Duplicate section header: "{metadata["section_header"]}"')
        
        quality_report['dimensions']['structural_integrity']['score'] = max(0, integrity_score)
        quality_report['dimensions']['structural_integrity']['issues'] = integrity_issues
        
        # ================================================================
        # CONTEXT SUFFICIENCY VALIDATION
        # ================================================================
        context_score = 1.0
        context_issues = []
        
        # Check for pronouns without antecedents at chunk start
        pronoun_patterns = [
            (r'^(It|This|That|These|Those|They)\s+', 'Pronoun without clear antecedent at start'),
            (r'^(However|Therefore|Thus|Hence|Consequently)', 'Transitional word without previous context'),
            (r'^(Additionally|Furthermore|Moreover)', 'Additive connector without base context')
        ]
        
        first_line = lines[0].strip() if lines else ''
        for pattern, issue in pronoun_patterns:
            if re.match(pattern, first_line):
                context_score -= 0.2
                context_issues.append(issue)
        
        # Check for acronyms without definitions
        acronym_pattern = r'\b[A-Z]{2,}(?:\s*[-/]\s*[A-Z]+)*\b'
        acronyms = re.findall(acronym_pattern, chunk)
        
        # Common FDOT acronyms that don't need definition
        known_acronyms = {'FDOT', 'ASTM', 'AASHTO', 'ACI', 'PDF', 'US', 'USA', 'ID', 'END'}
        undefined_acronyms = [a for a in set(acronyms) if a not in known_acronyms and f'({a})' not in chunk]
        
        if undefined_acronyms:
            context_score -= 0.1 * min(len(undefined_acronyms), 3)
            context_issues.append(f'Undefined acronyms: {", ".join(undefined_acronyms[:3])}')
        
        # Check for appropriate overlap (if metadata available)
        if metadata.get('has_smart_overlap'):
            # Good - smart overlap was applied
            pass
        else:
            context_score -= 0.1
            context_issues.append('No smart overlap applied for context preservation')
        
        quality_report['dimensions']['context_sufficiency']['score'] = max(0, context_score)
        quality_report['dimensions']['context_sufficiency']['issues'] = context_issues
        
        # ================================================================
        # CALCULATE OVERALL SCORE AND CLASSIFICATION
        # ================================================================
        
        # Weight the dimensions based on importance
        weights = {
            'completeness': 0.25,
            'coherence': 0.25,
            'information_density': 0.15,
            'structural_integrity': 0.20,
            'context_sufficiency': 0.15
        }
        
        overall_score = sum(
            quality_report['dimensions'][dim]['score'] * weight
            for dim, weight in weights.items()
        )
        
        quality_report['overall_score'] = round(overall_score, 2)
        
        # Classify chunk quality
        if overall_score >= 0.9:
            quality_report['quality_class'] = 'excellent'
        elif overall_score >= 0.75:
            quality_report['quality_class'] = 'good'
        elif overall_score >= 0.6:
            quality_report['quality_class'] = 'acceptable'
        else:
            quality_report['quality_class'] = 'poor'
            quality_report['requires_reprocessing'] = True
        
        # ================================================================
        # GENERATE RECOMMENDATIONS
        # ================================================================
        
        if quality_report['requires_reprocessing']:
            quality_report['recommendations'].append('Consider reprocessing this chunk with adjusted parameters')
        
        # Specific recommendations based on issues
        all_issues = []
        for dim in quality_report['dimensions'].values():
            all_issues.extend(dim['issues'])
        
        if 'Chunk starts mid-sentence' in str(all_issues):
            quality_report['recommendations'].append('Adjust chunk boundaries to start at sentence beginning')
        
        if 'Incomplete numbered list' in str(all_issues):
            quality_report['recommendations'].append('Extend chunk to include complete numbered sequence')
        
        if 'Incomplete table structure' in str(all_issues):
            quality_report['recommendations'].append('Ensure table-aware chunking is properly applied')
        
        if 'Insufficient content' in str(all_issues):
            quality_report['recommendations'].append('Consider merging with adjacent chunks or adjusting chunk size')
        
        if undefined_acronyms:
            quality_report['recommendations'].append(f'Add definitions for: {", ".join(undefined_acronyms[:3])}')
        
        return quality_report

    def _detect_and_extract_tables(self, text: str) -> Dict[str, Any]:
        """Detect and extract table boundaries for table-aware chunking.
        
        This method identifies table markers and extracts table information
        to ensure tables are treated as atomic units during chunking.
        
        Args:
            text: Text content to analyze for tables
            
        Returns:
            Dictionary with table locations, content, and metadata
        """
        table_info = {
            'tables': [],
            'table_boundaries': [],
            'text_without_tables': text,
            'has_tables': False
        }
        
        # Pattern to match our table markers: [TABLE X] ... [END TABLE X]
        table_pattern = r'\[TABLE\s+(\d+)[^\]]*\](.*?)\[END\s+TABLE\s+\1\]'
        
        matches = list(re.finditer(table_pattern, text, re.DOTALL | re.IGNORECASE))
        
        if matches:
            table_info['has_tables'] = True
            
            for match in matches:
                table_number = match.group(1)
                table_content = match.group(0)  # Full table including markers
                table_text_only = match.group(2).strip()  # Content between markers
                
                start_pos = match.start()
                end_pos = match.end()
                
                # Analyze table characteristics
                table_data = {
                    'table_number': table_number,
                    'full_content': table_content,
                    'text_content': table_text_only,
                    'start_position': start_pos,
                    'end_position': end_pos,
                    'length': len(table_content),
                    'row_count': len(table_text_only.split('\n')) if table_text_only else 0,
                    'is_large': len(table_content) > 800,  # Consider tables > 800 chars as large
                    'preceding_context': '',  # Will be filled when analyzing placement
                    'following_context': ''   # Will be filled when analyzing placement
                }
                
                table_info['tables'].append(table_data)
                table_info['table_boundaries'].append((start_pos, end_pos))
        
        return table_info

    def _find_table_context(self, text: str, table_data: Dict, context_window: int = 200) -> Dict[str, str]:
        """Find contextual text around tables for better placement decisions.
        
        Args:
            text: Full text content
            table_data: Table information dictionary
            context_window: Size of context window to extract
            
        Returns:
            Dictionary with preceding and following context
        """
        start_pos = table_data['start_position']
        end_pos = table_data['end_position']
        
        # Extract preceding context
        context_start = max(0, start_pos - context_window)
        preceding_text = text[context_start:start_pos].strip()
        
        # Extract following context  
        context_end = min(len(text), end_pos + context_window)
        following_text = text[end_pos:context_end].strip()
        
        # Clean up context - find sentence boundaries
        if preceding_text:
            # Find last complete sentence before table
            sentences = re.split(r'\.(\s+)', preceding_text)
            if len(sentences) > 1:
                preceding_text = '.'.join(sentences[:-1]) + '.'
        
        if following_text:
            # Find first complete sentence after table
            first_sentence = re.split(r'\.(\s+)', following_text)
            if first_sentence:
                following_text = first_sentence[0] + '.' if not first_sentence[0].endswith('.') else first_sentence[0]
        
        return {
            'preceding_context': preceding_text,
            'following_context': following_text
        }

    def _create_table_aware_chunks(self, text: str, chunk_size: int) -> List[str]:
        """Create chunks that respect table boundaries and maintain table integrity.
        
        This method implements table-aware chunking by:
        1. Detecting all tables in the text
        2. Creating chunks that never split tables
        3. Intelligently placing tables with appropriate context
        4. Handling oversized tables gracefully
        
        Args:
            text: Text content to chunk
            chunk_size: Target size for chunks
            
        Returns:
            List of table-aware text chunks
        """
        # Step 1: Detect and analyze tables
        table_info = self._detect_and_extract_tables(text)
        
        if not table_info['has_tables']:
            # No tables - use standard processing
            return []  # Let standard splitter handle this
        
        # Step 2: Analyze table contexts
        for table_data in table_info['tables']:
            context = self._find_table_context(text, table_data)
            table_data.update(context)
        
        # Step 3: Create table-aware chunks
        chunks = []
        current_pos = 0
        
        for i, table_data in enumerate(table_info['tables']):
            table_start = table_data['start_position']
            table_end = table_data['end_position']
            table_content = table_data['full_content']
            
            # Get text before this table
            pre_table_text = text[current_pos:table_start].strip()
            
            # Decide how to handle the table placement
            table_with_context = self._determine_table_placement(
                pre_table_text, 
                table_data, 
                chunk_size
            )
            
            # Add pre-table chunks if needed
            if table_with_context['pre_table_chunk']:
                chunks.append(table_with_context['pre_table_chunk'])
            
            # Add table chunk
            chunks.append(table_with_context['table_chunk'])
            
            # Update position
            current_pos = table_end
        
        # Handle remaining text after last table
        remaining_text = text[current_pos:].strip()
        if remaining_text:
            chunks.append(remaining_text)
        
        return chunks

    def _determine_table_placement(self, pre_table_text: str, table_data: Dict, chunk_size: int) -> Dict[str, str]:
        """Determine optimal placement strategy for a table with its context.
        
        Args:
            pre_table_text: Text before the table
            table_data: Table information and metadata
            chunk_size: Target chunk size
            
        Returns:
            Dictionary with pre_table_chunk and table_chunk decisions
        """
        table_content = table_data['full_content']
        table_length = table_data['length']
        preceding_context = table_data['preceding_context']
        
        # Calculate combined size
        context_size = len(preceding_context) if preceding_context else 0
        combined_size = context_size + table_length
        
        # Strategy 1: Table with immediate context fits in one chunk
        if combined_size <= chunk_size * 0.9:  # 90% of chunk size for buffer
            return {
                'pre_table_chunk': pre_table_text[:-len(preceding_context)].strip() if preceding_context and len(pre_table_text) > len(preceding_context) else '',
                'table_chunk': f"{preceding_context}\n{table_content}".strip()
            }
        
        # Strategy 2: Table alone fits in chunk size
        elif table_length <= chunk_size:
            return {
                'pre_table_chunk': pre_table_text,
                'table_chunk': table_content
            }
        
        # Strategy 3: Large table handling - break at natural boundaries if possible
        else:
            # For very large tables, we still keep them atomic but may need special handling
            # This is a design decision - we prioritize table integrity over chunk size
            return {
                'pre_table_chunk': pre_table_text,
                'table_chunk': table_content  # Keep table atomic even if large
            }

    # ========================================================================
    # CONTENT EXTRACTION METHODS
    # ========================================================================
    
    def _table_to_text(self, table: List[List]) -> str:
        """Convert extracted table data into readable text format.
        
        This method handles various table formats and edge cases including:
        - Empty rows and cells
        - Inconsistent column counts
        - Header detection and formatting
        - Fallback to simple pipe-separated format if pandas formatting fails
        
        Args:
            table: List of lists representing table rows and cells
            
        Returns:
            Formatted table as string, or empty string if table is invalid
        """
        if not table:
            return ""
        
        try:
            # Clean the table data
            cleaned_table = []
            for row in table:
                if row:  # Skip completely empty rows
                    cleaned_row = [str(cell).strip() if cell is not None else '' for cell in row]
                    # Only add rows that have some content
                    if any(cell for cell in cleaned_row):
                        cleaned_table.append(cleaned_row)
            
            if not cleaned_table:
                return ""
            
            # Try pandas formatting first
            try:
                # Use first row as headers if it looks like headers
                headers = cleaned_table[0]
                data_rows = cleaned_table[1:] if len(cleaned_table) > 1 else []
                
                if data_rows:
                    df = pd.DataFrame(data_rows, columns=headers)
                    return df.to_string(index=False, na_rep='', max_cols=None)
                else:
                    # Single row table
                    return ' | '.join(headers)
            
            except Exception:
                # Fallback to simple formatting
                text_lines = []
                for row in cleaned_table:
                    text_lines.append(' | '.join(row))
                return '\n'.join(text_lines)
        
        except Exception as e:
            print(f"⚠️  Table formatting failed: {e}")
            return "[TABLE FORMATTING ERROR]"
    
    def extract_page_content(self, page, page_num: int) -> Dict[str, Any]:
        """Extract comprehensive content from a single PDF page using multiple methods.
        
        This method employs a multi-layered extraction strategy:
        1. Standard text extraction with pdfplumber
        2. Layout-aware text extraction as fallback
        3. Character-level extraction for difficult pages
        4. Table extraction with formatting
        5. Image extraction with OCR (if available)
        
        Args:
            page: pdfplumber page object
            page_num: Page number for metadata and error reporting
            
        Returns:
            Dictionary containing extracted text, tables, images, and metadata
        """
        
        extracted_text = ""
        
        # ====================================================================
        # TEXT EXTRACTION - MULTI-LAYER APPROACH
        # ====================================================================
        
        # Method 1: Standard text extraction (most reliable for well-formed PDFs)
        try:
            primary_text = page.extract_text() or ""
            extracted_text += primary_text
            
            if primary_text:
                self.extraction_stats['total_text_extracted'] += len(primary_text)
        except Exception as e:
            print(f"⚠️  Text extraction failed on page {page_num}: {e}")
            self.extraction_stats['text_extraction_failures'] += 1
        
        # Method 2: Layout-aware extraction (fallback for complex layouts)
        if not extracted_text.strip():
            try:
                # Preserve spatial layout for better structure detection
                alt_text = page.extract_text(layout=True) or ""
                extracted_text += alt_text
                
                if alt_text:
                    self.extraction_stats['total_text_extracted'] += len(alt_text)
            except Exception as e:
                print(f"⚠️  Alternative text extraction failed on page {page_num}: {e}")
        
        # Method 3: Character-level extraction (last resort for problematic PDFs)
        if not extracted_text.strip():
            try:
                chars = page.chars
                if chars:
                    char_text = "".join([char.get('text', '') for char in chars])
                    extracted_text += char_text
                    
                    if char_text:
                        self.extraction_stats['total_text_extracted'] += len(char_text)
            except Exception as e:
                print(f"⚠️  Character-level extraction failed on page {page_num}: {e}")
        
        # ====================================================================
        # TABLE EXTRACTION AND FORMATTING
        # ====================================================================
        # Extract and format tables, embedding them directly into the text stream
        tables = []
        try:
            page_tables = page.extract_tables()
            for i, table in enumerate(page_tables or []):
                if table and any(any(cell for cell in row if cell) for row in table):  # Skip truly empty tables
                    table_data = {
                        'table_id': f"page_{page_num}_table_{i}",
                        'raw_data': table,
                        'text_representation': self._table_to_text(table),
                        'row_count': len(table),
                        'col_count': len(table[0]) if table else 0
                    }
                    tables.append(table_data)
                    self.extraction_stats['total_tables_found'] += 1
                    
                    # Add table text to main content
                    extracted_text += f"\n\n[TABLE {i+1} ON PAGE {page_num}]\n"
                    extracted_text += table_data['text_representation']
                    extracted_text += f"\n[END TABLE {i+1}]\n"
        
        except Exception as e:
            print(f"⚠️  Table extraction failed on page {page_num}: {e}")
            self.extraction_stats['table_extraction_failures'] += 1
        
        # ====================================================================
        # IMAGE EXTRACTION WITH OCR
        # ====================================================================
        # Extract text content from images using OCR (if pytesseract is available)
        images = []
        if OCR_AVAILABLE:
            try:
                page_images = page.images
                for i, img in enumerate(page_images or []):
                    images.append({
                        'image_id': f"page_{page_num}_img_{i}",
                        'bbox': img
                    })
                    
                    # Extract the image and run OCR
                    try:
                        # Get image bounds
                        x0, y0, x1, y1 = img['x0'], img['top'], img['x1'], img['bottom']
                        
                        # Skip very small images (likely decorative)
                        if (x1 - x0) > 50 and (y1 - y0) > 50:
                            # Convert page to image and crop
                            pil_page = page.to_image(resolution=300).original
                            cropped_img = pil_page.crop((x0, y0, x1, y1))
                            
                            # Run OCR
                            ocr_text = pytesseract.image_to_string(cropped_img, config='--psm 6')
                            
                            if ocr_text.strip() and len(ocr_text.strip()) > 5:
                                extracted_text += f"\n\n[OCR FIGURE {i+1} ON PAGE {page_num}]\n"
                                extracted_text += ocr_text.strip()
                                extracted_text += f"\n[END OCR FIGURE {i+1}]\n"
                                print(f"   📷 OCR extracted {len(ocr_text)} chars from image {i+1} on page {page_num}")
                            else:
                                extracted_text += f"\n\n[FIGURE {i+1} ON PAGE {page_num} - minimal text]\n"
                        
                    except Exception as ocr_e:
                        print(f"⚠️  OCR failed for image {i+1} on page {page_num}: {ocr_e}")
                        extracted_text += f"\n\n[FIGURE {i+1} ON PAGE {page_num} - OCR failed]\n"
                        self.extraction_stats['ocr_extraction_failures'] += 1
            
            except Exception as e:
                print(f"⚠️  Image extraction failed on page {page_num}: {e}")
        
        # Update stats
        self.extraction_stats['total_pages_processed'] += 1
        
        # Page metadata
        page_metadata = {
            'page_number': page_num,
            'text_length': len(extracted_text),
            'table_count': len(tables),
            'image_count': len(images),
            'extraction_method': 'enhanced_pdfplumber'
        }
        
        return {
            'text': extracted_text,
            'tables': tables,
            'images': images,
            'metadata': page_metadata
        }

    # ========================================================================
    # DOCUMENT PROCESSING STRATEGIES
    # ========================================================================
    
    def split_pdf(self, input_pdf: Path, output_dir: Path, pages_per_slice: int = 200) -> List[tuple]:
        """Split a large PDF into manageable smaller PDFs for memory-efficient processing.
        
        Args:
            input_pdf: Path to the input PDF file
            output_dir: Directory to store the PDF slices
            pages_per_slice: Number of pages per slice (default: 200)
            
        Returns:
            List of tuples containing (slice_path, start_page, end_page) for each slice
        """
        output_dir.mkdir(exist_ok=True)
        reader = PdfReader(str(input_pdf))
        total_pages = len(reader.pages)
        slice_paths = []
        
        print(f"   🔪 Splitting into {(total_pages + pages_per_slice - 1) // pages_per_slice} slices of {pages_per_slice} pages")
        
        for start in range(0, total_pages, pages_per_slice):
            end = min(start + pages_per_slice, total_pages)
            writer = PdfWriter()
            for i in range(start, end):
                writer.add_page(reader.pages[i])
            slice_path = output_dir / f"{input_pdf.stem}_slice_{start+1}-{end}.pdf"
            with open(slice_path, "wb") as f:
                writer.write(f)
            slice_paths.append((slice_path, start+1, end))
        
        return slice_paths
    
    def process_pdf_slice(self, slice_path: Path, start_page: int, end_page: int, original_pdf_name: str, slice_number: int) -> List[EnhancedDocumentChunk]:
        """Process a single PDF slice with comprehensive content extraction and chunking.
        
        This method processes one slice of a large PDF, maintaining correct page numbering
        and metadata references to the original document.
        
        Args:
            slice_path: Path to the PDF slice file
            start_page: Starting page number in the original document
            end_page: Ending page number in the original document
            original_pdf_name: Name of the original PDF file for metadata
            slice_number: Sequential slice number for tracking
            
        Returns:
            List of EnhancedDocumentChunk objects with comprehensive metadata
        """
        chunks = []
        
        with pdfplumber.open(slice_path) as pdf:
            total_pages_in_slice = len(pdf.pages)
            print(f"     📄 Processing slice {slice_number}: pages {start_page}-{end_page} ({total_pages_in_slice} pages)")
            
            for page_idx, page in enumerate(pdf.pages):
                actual_page_num = start_page + page_idx
                
                # Extract comprehensive page content using multi-layer approach
                page_content = self.extract_page_content(page, actual_page_num)
                
                page_text = page_content['text']
                if not page_text.strip():
                    continue  # Skip pages with no extractable text
                
                # ============================================================
                # CHUNKING STRATEGY: ADAPTIVE SEMANTIC-AWARE TEXT SPLITTING
                # ============================================================
                # Analyze content characteristics for optimal chunk sizing
                content_analysis = self._analyze_content_characteristics(page_text)
                
                # Split page text using semantic awareness and adaptive sizing
                text_chunks = self._split_text_semantically(page_text)
                
                for chunk_idx, chunk_text in enumerate(text_chunks):
                    if not chunk_text.strip():
                        continue  # Skip empty chunks
                    
                    # ========================================================
                    # CHUNK METADATA CREATION
                    # ========================================================
                    # Create comprehensive metadata for each chunk including source tracking,
                    # processing context, and content analysis
                    metadata = {
                        'source': original_pdf_name,                                    # Original document name
                        'source_file': original_pdf_name,                               # Consistent field for RAG service
                        'slice_number': slice_number,                                   # Which slice this chunk came from
                        'original_pages': f"{start_page}-{end_page}",                  # Page range of the slice
                        'page_number': actual_page_num,                                # Actual page number in original document
                        'chunk_index': chunk_idx,                                      # Index of chunk within the page
                        'total_chunks_on_page': len(text_chunks),                      # Total chunks created from this page
                        'chunk_length': len(chunk_text),                               # Length in characters
                        'tables_on_page': len(page_content.get('tables', [])),        # Number of tables found on page
                        'has_tables': len(page_content.get('tables', [])) > 0,        # Boolean flag for table presence
                        'table_data': page_content['tables'] if chunk_idx == 0 else None,  # Table data (only on first chunk to avoid duplication)
                        'section_header': self._detect_section_header(chunk_text),     # Detected section header
                        'is_semantic_chunk': True,                                     # Flag indicating semantic-aware chunking was used
                        'chunking_method': 'adaptive_semantic_table_aware' if '[TABLE' in chunk_text and '[END TABLE' in chunk_text else 'adaptive_semantic_aware',  # Type of chunking applied
                        'content_type': content_analysis['content_type'],             # Detected content type
                        'content_density_score': content_analysis['density_score'],   # Content density analysis
                        'optimal_chunk_size': content_analysis['optimal_chunk_size'], # Recommended chunk size for this content
                        'structure_indicators': content_analysis['structure_indicators'], # Structural features detected
                        'has_smart_overlap': True,                                     # Flag indicating smart overlap was applied
                        'overlap_strategy': 'content_adaptive',                       # Type of overlap strategy used
                        'is_table_aware': '[TABLE' in chunk_text and '[END TABLE' in chunk_text,  # Flag for table-aware processing
                        'table_integrity_preserved': True,                            # Tables are never split across chunks
                        'extraction_method': 'sliced_processing',                      # Processing method used
                        'processing_time': time.time()                                # Timestamp for processing tracking
                    }
                    
                    chunk_id = hashlib.md5(f"{original_pdf_name}_{actual_page_num}_{chunk_idx}_{slice_number}".encode()).hexdigest()
                    
                    # ========================================================
                    # CHUNK QUALITY VALIDATION
                    # ========================================================
                    # Validate chunk quality before finalizing
                    quality_assessment = self._validate_chunk_quality(chunk_text, metadata)
                    
                    # Add quality assessment to metadata
                    metadata['quality_assessment'] = {
                        'overall_score': quality_assessment['overall_score'],
                        'quality_class': quality_assessment['quality_class'],
                        'requires_reprocessing': quality_assessment['requires_reprocessing'],
                        'dimensions': {
                            dim: {'score': info['score'], 'issue_count': len(info['issues'])}
                            for dim, info in quality_assessment['dimensions'].items()
                        }
                    }
                    
                    # Log quality issues for poor chunks
                    if quality_assessment['quality_class'] == 'poor':
                        print(f"     ⚠️ Poor quality chunk detected on page {actual_page_num}:")
                        for dim, info in quality_assessment['dimensions'].items():
                            if info['issues']:
                                print(f"        - {dim}: {', '.join(info['issues'][:2])}")
                    
                    chunk = EnhancedDocumentChunk(
                        content=chunk_text,
                        metadata=metadata,
                        chunk_id=chunk_id,
                        page_number=actual_page_num,
                        tables=page_content['tables'] if chunk_idx == 0 else None,
                        section_info=None
                    )
                    
                    chunks.append(chunk)
                
                # Memory cleanup
                gc.collect()
        
        return chunks
    
    def process_large_pdf_with_slicing(self, pdf_path: Path, pages_per_slice: int = 200) -> List[EnhancedDocumentChunk]:
        """Process large PDF files using a slicing strategy for memory management.
        
        This method handles large PDFs by:
        1. Splitting the PDF into manageable slices
        2. Processing each slice independently
        3. Combining results while maintaining document structure
        4. Cleaning up temporary files
        
        Args:
            pdf_path: Path to the large PDF file
            pages_per_slice: Number of pages per slice (default: 200)
            
        Returns:
            List of EnhancedDocumentChunk objects from all slices combined
        """
        
        print(f"   🔪 Large file detected - using slicing approach")
        
        # Create temporary directory for slices
        temp_dir = Path("temp_slices")
        temp_dir.mkdir(exist_ok=True)
        
        try:
            # Split PDF into manageable slices
            slices = self.split_pdf(pdf_path, temp_dir, pages_per_slice)
            
            # Process each slice
            all_chunks = []
            
            for slice_number, (slice_path, start_page, end_page) in enumerate(slices, 1):
                try:
                    chunks = self.process_pdf_slice(
                        slice_path, start_page, end_page, pdf_path.name, slice_number
                    )
                    all_chunks.extend(chunks)
                    
                except Exception as e:
                    print(f"     ❌ Error processing slice {slice_number}: {e}")
                
                finally:
                    # Clean up temp file
                    try:
                        os.remove(slice_path)
                    except Exception as e:
                        print(f"     ⚠️  Could not remove {slice_path}: {e}")
            
            return all_chunks
        
        finally:
            # Clean up temp directory
            try:
                temp_dir.rmdir()
            except:
                pass  # Directory may contain files or not exist
    
    def process_document_direct(self, pdf_path: Path, max_pages: int = None) -> List[EnhancedDocumentChunk]:
        """Process smaller PDF files directly without slicing for maximum efficiency.
        
        This method is used for files below the size/page thresholds and provides:
        - Direct page-by-page processing
        - Memory-efficient single-pass extraction
        - Progress tracking for longer documents
        - Identical chunking strategy to sliced processing
        
        Args:
            pdf_path: Path to the PDF file
            max_pages: Maximum number of pages to process (None for all pages)
            
        Returns:
            List of EnhancedDocumentChunk objects
        """
        
        all_chunks = []
        
        try:
            with pdfplumber.open(pdf_path) as pdf:
                total_pages = len(pdf.pages)
                pages_to_process = min(max_pages or total_pages, total_pages)
                
                print(f"   📖 Direct processing: {pages_to_process}/{total_pages} pages")
                
                # Progress tracking for large documents
                for page_num in range(pages_to_process):
                    page = pdf.pages[page_num]
                    
                    # Progress updates every 50 pages
                    if total_pages > 100 and (page_num + 1) % 50 == 0:
                        progress_pct = ((page_num + 1) / pages_to_process) * 100
                        print(f"     📊 Progress: {page_num + 1}/{pages_to_process} pages ({progress_pct:.0f}%)")
                    
                    page_content = self.extract_page_content(page, page_num + 1)
                    
                    page_text = page_content['text']
                    if not page_text.strip():
                        continue
                    
                    # Analyze content characteristics for adaptive sizing
                    content_analysis = self._analyze_content_characteristics(page_text)
                    
                    # Split into chunks using adaptive semantic awareness
                    text_chunks = self._split_text_semantically(page_text)
                    
                    for chunk_idx, chunk_text in enumerate(text_chunks):
                        if not chunk_text.strip():
                            continue
                        
                        metadata = {
                            'source': str(pdf_path),
                            'source_file': pdf_path.name,  # Consistent field for RAG service
                            'file_name': pdf_path.name,
                            'page_number': page_num + 1,
                            'chunk_index': chunk_idx,
                            'total_chunks_on_page': len(text_chunks),
                            'chunk_length': len(chunk_text),
                            'has_tables': len(page_content.get('tables', [])) > 0,
                            'table_count': len(page_content.get('tables', [])),
                            'section_header': self._detect_section_header(chunk_text),
                            'is_semantic_chunk': True,                                     # Flag indicating semantic-aware chunking was used
                            'chunking_method': 'adaptive_semantic_table_aware' if '[TABLE' in chunk_text and '[END TABLE' in chunk_text else 'adaptive_semantic_aware',  # Type of chunking applied
                            'content_type': content_analysis['content_type'],             # Detected content type
                            'content_density_score': content_analysis['density_score'],   # Content density analysis
                            'optimal_chunk_size': content_analysis['optimal_chunk_size'], # Recommended chunk size for this content
                            'structure_indicators': content_analysis['structure_indicators'], # Structural features detected
                            'has_smart_overlap': True,                                     # Flag indicating smart overlap was applied
                            'overlap_strategy': 'content_adaptive',                       # Type of overlap strategy used
                            'is_table_aware': '[TABLE' in chunk_text and '[END TABLE' in chunk_text,  # Flag for table-aware processing
                            'table_integrity_preserved': True,                            # Tables are never split across chunks
                            'extraction_method': 'direct_processing'
                        }
                        
                        chunk_id = hashlib.md5(f"{pdf_path}_{page_num}_{chunk_idx}".encode()).hexdigest()
                        
                        # ====================================================
                        # CHUNK QUALITY VALIDATION
                        # ====================================================
                        # Validate chunk quality before finalizing
                        quality_assessment = self._validate_chunk_quality(chunk_text, metadata)
                        
                        # Add quality assessment to metadata
                        metadata['quality_assessment'] = {
                            'overall_score': quality_assessment['overall_score'],
                            'quality_class': quality_assessment['quality_class'],
                            'requires_reprocessing': quality_assessment['requires_reprocessing'],
                            'dimensions': {
                                dim: {'score': info['score'], 'issue_count': len(info['issues'])}
                                for dim, info in quality_assessment['dimensions'].items()
                            }
                        }
                        
                        # Log quality issues for poor chunks
                        if quality_assessment['quality_class'] == 'poor':
                            print(f"     ⚠️ Poor quality chunk detected on page {page_num + 1}:")
                            for dim, info in quality_assessment['dimensions'].items():
                                if info['issues']:
                                    print(f"        - {dim}: {', '.join(info['issues'][:2])}")
                        
                        chunk = EnhancedDocumentChunk(
                            content=chunk_text,
                            metadata=metadata,
                            chunk_id=chunk_id,
                            page_number=page_num + 1,
                            tables=page_content['tables'] if chunk_idx == 0 else None,
                            section_info=None
                        )
                        
                        all_chunks.append(chunk)
        
        except Exception as e:
            print(f"   ❌ Error in direct processing: {e}")
            import traceback
            traceback.print_exc()
        
        return all_chunks
    
    def should_use_slicing(self, pdf_path: Path) -> tuple[bool, str]:
        """Determine if file should be processed with slicing."""
        
        file_size_mb = pdf_path.stat().st_size / (1024 * 1024)
        
        # Check file size threshold
        if file_size_mb > self.large_file_threshold_mb:
            return True, f"file size ({file_size_mb:.1f}MB > {self.large_file_threshold_mb}MB)"
        
        # Check page count threshold
        try:
            with pdfplumber.open(pdf_path) as pdf:
                total_pages = len(pdf.pages)
                if total_pages > self.large_file_threshold_pages:
                    return True, f"page count ({total_pages} > {self.large_file_threshold_pages})"
        except:
            pass  # If we can't read page count, default to file size check
        
        return False, "within normal limits"
    
    def process_document(self, pdf_path: Path, max_pages: int = None) -> List[EnhancedDocumentChunk]:
        """Intelligent document processing with automatic strategy selection.
        
        This is the main entry point for document processing. It automatically
        determines the optimal processing strategy based on file characteristics:
        
        Strategy Selection Criteria:
        - File size > threshold MB → Slicing approach
        - Page count > threshold pages → Slicing approach  
        - Otherwise → Direct processing
        
        Both strategies use identical content extraction and chunking methods,
        ensuring consistent output regardless of processing approach.
        
        Args:
            pdf_path: Path to the PDF file to process
            max_pages: Maximum pages to process (None for all pages)
            
        Returns:
            List of EnhancedDocumentChunk objects with comprehensive metadata
        """
        
        print(f"📄 Processing: {pdf_path.name}")
        
        # Check if we should use slicing
        use_slicing, reason = self.should_use_slicing(pdf_path)
        
        if use_slicing:
            print(f"   🎯 Using slicing approach: {reason}")
            chunks = self.process_large_pdf_with_slicing(pdf_path)
            self.extraction_stats['sliced_processing_documents'] += 1
        else:
            print(f"   🎯 Using direct processing: {reason}")
            chunks = self.process_document_direct(pdf_path, max_pages)
            self.extraction_stats['direct_processing_documents'] += 1
        
        # Final summary
        total_text_length = sum(len(chunk.content) for chunk in chunks)
        total_tables = sum(chunk.metadata.get('table_count', 0) for chunk in chunks)
        
        print(f"   ✅ Extracted {len(chunks)} chunks ({total_text_length:,} characters)")
        if total_tables > 0:
            print(f"   📋 Found {total_tables} tables")
        
        return chunks
    
    def _detect_document_type(self, pdf_path: Path) -> str:
        """Simple document type detection."""
        
        filename = pdf_path.name.lower()
        parent_dir = pdf_path.parent.name.lower()
        
        # Filename patterns
        if any(pattern in filename for pattern in ['spec', 'specification']):
            return 'specification'
        elif 'manual' in filename:
            return 'manual'
        elif any(pattern in filename for pattern in ['standard', 'plan']):
            return 'standard_plan'
        elif any(pattern in filename for pattern in ['fdm', 'design']):
            return 'design_manual'
        
        # Directory patterns
        if any(pattern in parent_dir for pattern in ['specbook', 'spec']):
            return 'specification'
        elif 'manual' in parent_dir:
            return 'manual'
        elif any(pattern in parent_dir for pattern in ['standard', 'plan']):
            return 'standard_plan'
        elif any(pattern in parent_dir for pattern in ['fdm', 'design']):
            return 'design_manual'
        
        return 'document'
    
    def _detect_section_header(self, text: str) -> Optional[str]:
        """Detect section headers with improved patterns."""
        
        lines = text.split('\n')[:5]
        
        patterns = [
            r'^\d+[\.\-]\d*[\.\-]*\d*\s+[A-Z]',  # e.g., "1.1.1 GENERAL"
            r'^[A-Z][A-Z\s]{5,50}$',              # e.g., "GENERAL REQUIREMENTS"
            r'^\d+\s+[A-Z]',                      # e.g., "100 Construction Equipment"
            r'^[A-Z]+\s*\d+[\.\-]\d*',           # e.g., "SECTION 1.1"
            r'^\d+\.\d+\s+[A-Z]',                 # e.g., "10.1 MATERIALS"
        ]
        
        for line in lines:
            line = line.strip()
            for pattern in patterns:
                if re.match(pattern, line) and len(line) < 100:
                    return line
        
        return None
    
    def _generate_quality_summary(self, chunks: List[EnhancedDocumentChunk]) -> Dict[str, Any]:
        """Generate a comprehensive quality summary report for all chunks.
        
        Args:
            chunks: List of processed chunks with quality assessments
            
        Returns:
            Dictionary with quality statistics and insights
        """
        if not chunks:
            return {'error': 'No chunks to analyze'}
        
        summary = {
            'total_chunks': len(chunks),
            'quality_distribution': {
                'excellent': 0,
                'good': 0,
                'acceptable': 0,
                'poor': 0
            },
            'average_quality_score': 0.0,
            'dimensions_summary': {
                'completeness': {'avg_score': 0.0, 'common_issues': {}},
                'coherence': {'avg_score': 0.0, 'common_issues': {}},
                'information_density': {'avg_score': 0.0, 'common_issues': {}},
                'structural_integrity': {'avg_score': 0.0, 'common_issues': {}},
                'context_sufficiency': {'avg_score': 0.0, 'common_issues': {}}
            },
            'chunks_requiring_reprocessing': 0,
            'top_recommendations': {},
            'quality_by_content_type': {},
            'quality_insights': []
        }
        
        # Collect quality data
        total_score = 0.0
        dimension_scores = {dim: [] for dim in summary['dimensions_summary']}
        all_issues = {dim: [] for dim in summary['dimensions_summary']}
        content_type_quality = {}
        
        for chunk in chunks:
            quality = chunk.metadata.get('quality_assessment', {})
            if not quality:
                continue
            
            # Overall metrics
            total_score += quality.get('overall_score', 0.0)
            quality_class = quality.get('quality_class', 'unknown')
            if quality_class in summary['quality_distribution']:
                summary['quality_distribution'][quality_class] += 1
            
            # Track reprocessing needs
            if quality.get('requires_reprocessing', False):
                summary['chunks_requiring_reprocessing'] += 1
            
            # Dimension-specific tracking
            for dim, info in quality.get('dimensions', {}).items():
                if dim in dimension_scores:
                    dimension_scores[dim].append(info['score'])
                    if info['issue_count'] > 0:
                        all_issues[dim].extend([f"{dim}_issue"] * info['issue_count'])
            
            # Content type analysis
            content_type = chunk.metadata.get('content_type', 'general')
            if content_type not in content_type_quality:
                content_type_quality[content_type] = []
            content_type_quality[content_type].append(quality.get('overall_score', 0.0))
        
        # Calculate averages
        if chunks:
            summary['average_quality_score'] = round(total_score / len(chunks), 2)
        
        # Dimension summaries
        for dim in summary['dimensions_summary']:
            if dimension_scores[dim]:
                summary['dimensions_summary'][dim]['avg_score'] = round(
                    sum(dimension_scores[dim]) / len(dimension_scores[dim]), 2
                )
        
        # Content type quality summary
        for content_type, scores in content_type_quality.items():
            if scores:
                summary['quality_by_content_type'][content_type] = {
                    'avg_score': round(sum(scores) / len(scores), 2),
                    'chunk_count': len(scores)
                }
        
        # Generate insights
        if summary['average_quality_score'] >= 0.85:
            summary['quality_insights'].append("✅ Overall chunk quality is EXCELLENT")
        elif summary['average_quality_score'] >= 0.70:
            summary['quality_insights'].append("👍 Overall chunk quality is GOOD")
        else:
            summary['quality_insights'].append("⚠️ Overall chunk quality needs improvement")
        
        # Identify problem areas
        for dim, info in summary['dimensions_summary'].items():
            if info['avg_score'] < 0.7:
                summary['quality_insights'].append(f"📍 {dim.title()} needs attention (avg: {info['avg_score']})")
        
        # Quality class insights
        poor_percentage = (summary['quality_distribution']['poor'] / max(len(chunks), 1)) * 100
        if poor_percentage > 10:
            summary['quality_insights'].append(f"⚠️ {poor_percentage:.1f}% of chunks are poor quality")
        
        excellent_percentage = (summary['quality_distribution']['excellent'] / max(len(chunks), 1)) * 100
        if excellent_percentage > 50:
            summary['quality_insights'].append(f"🌟 {excellent_percentage:.1f}% of chunks are excellent quality!")
        
        return summary


# ============================================================================
# UTILITY FUNCTIONS FOR MEMORY MANAGEMENT AND PARALLEL PROCESSING
# ============================================================================

def check_memory_available() -> float:
    """Check currently available system memory.
    
    Returns:
        Available memory in gigabytes (float)
    """
    mem = psutil.virtual_memory()
    return mem.available / (1024**3)  # Convert bytes to GB


def estimate_memory_requirement(file_size_mb: float) -> float:
    """Estimate memory requirements for PDF processing based on file size.
    
    Based on empirical observation, PDF processing with pdfplumber requires
    approximately 10-15x the file size in RAM due to:
    - Page object creation and caching
    - Text extraction and processing
    - Table detection and parsing
    - Image handling and OCR operations
    
    Args:
        file_size_mb: File size in megabytes
        
    Returns:
        Estimated memory requirement in gigabytes
    """
    return (file_size_mb * 12) / 1024  # Conservative 12x multiplier, convert to GB


def create_smart_batches(pdf_files_info: List[Dict], available_memory_gb: float) -> List[List[Dict]]:
    """Create intelligent batches for parallel processing based on memory constraints.
    
    This function implements a sophisticated batching strategy that:
    - Categorizes files by size (large, medium, small)
    - Processes very large files (>100MB) solo
    - Pairs large files (50-100MB) when memory allows
    - Batches medium files (20-50MB) conservatively
    - Batches small files (<20MB) more aggressively
    
    The strategy prioritizes memory safety over processing speed to prevent
    out-of-memory errors during parallel processing.
    
    Args:
        pdf_files_info: List of PDF file info dictionaries with size data
        available_memory_gb: Available system memory in GB
        
    Returns:
        List of batches, where each batch is a list of PDF file info dictionaries
    """
    sorted_files = sorted(pdf_files_info, key=lambda x: x.get('size', 0), reverse=True)
    
    batches = []
    large_file_threshold_mb = 50  # Files over this get special treatment
    
    print(f"   📊 Available memory: {available_memory_gb:.1f}GB")
    
    # First, separate large files that need solo processing
    large_files = []
    medium_files = []
    small_files = []
    
    for pdf_info in sorted_files:
        file_size_mb = pdf_info.get('size', 0) / (1024*1024)
        if file_size_mb > 100:  # Very large files - always solo
            batches.append([pdf_info])
            print(f"   ⚠️ {pdf_info['filename']} ({file_size_mb:.1f}MB) will be processed alone (very large)")
        elif file_size_mb > 50:  # Large files - solo or very limited batching
            large_files.append(pdf_info)
        elif file_size_mb > 20:  # Medium files
            medium_files.append(pdf_info)
        else:  # Small files
            small_files.append(pdf_info)
    
    # Process large files solo or in pairs max
    for i in range(0, len(large_files), 2):
        if i + 1 < len(large_files):
            # Check if two large files together are safe
            total_mb = sum(f.get('size', 0)/(1024*1024) for f in large_files[i:i+2])
            if total_mb * 12 / 1024 < available_memory_gb * 0.5:  # Very conservative
                batches.append(large_files[i:i+2])
                print(f"   📦 Large files batch: {len(large_files[i:i+2])} files, {total_mb:.1f}MB total")
            else:
                batches.append([large_files[i]])
                batches.append([large_files[i+1]])
                print(f"   ⚠️ {large_files[i]['filename']} will be processed alone (large)")
                print(f"   ⚠️ {large_files[i+1]['filename']} will be processed alone (large)")
        else:
            batches.append([large_files[i]])
            print(f"   ⚠️ {large_files[i]['filename']} will be processed alone (large)")
    
    # Medium files in small batches
    if medium_files:
        batch_size = min(3, max(1, int(available_memory_gb / 10)))  # Conservative
        for i in range(0, len(medium_files), batch_size):
            batch = medium_files[i:i+batch_size]
            total_mb = sum(f.get('size', 0)/(1024*1024) for f in batch)
            batches.append(batch)
            print(f"   📦 Medium files batch: {len(batch)} files, {total_mb:.1f}MB total")
    
    # Small files can be batched more aggressively
    if small_files:
        batch_size = min(4, max(1, int(available_memory_gb / 5)))
        for i in range(0, len(small_files), batch_size):
            batch = small_files[i:i+batch_size]
            total_mb = sum(f.get('size', 0)/(1024*1024) for f in batch)
            batches.append(batch)
            print(f"   📦 Small files batch: {len(batch)} files, {total_mb:.1f}MB total")
    
    return batches


def get_workers_for_batch(batch: List[Dict], available_memory_gb: float) -> int:
    """Determine optimal workers for a specific batch."""
    if len(batch) == 1:
        return 1  # Single file always gets 1 worker
    
    # Get individual file memory requirements
    file_memories = [estimate_memory_requirement(f.get('size', 0)/(1024*1024)) for f in batch]
    max_file_memory = max(file_memories)
    
    # Can't parallelize if any single file needs more than half available memory
    if max_file_memory > available_memory_gb * 0.35:
        return 1
    
    # Calculate based on total batch memory
    total_memory_needed = sum(file_memories)
    safety_factor = 0.7
    max_parallel_memory = available_memory_gb * safety_factor
    
    # How many concurrent processes can we fit?
    workers = int(max_parallel_memory / max_file_memory)
    
    return max(1, min(workers, len(batch), 4))


def process_single_pdf(pdf_info: Dict[str, Any], max_pages_per_file: int = None) -> Dict[str, Any]:
    """Process a single PDF file - used for parallel processing."""
    
    try:
        # Download PDF from MinIO
        identifier = pdf_info.get('object_name', pdf_info['filename'])
        local_pdf_path = pdf_manager.download_pdf(identifier, use_cache=True)
        
        # Create processor instance
        processor = IntegratedFDOTProcessor(
            large_file_threshold_mb=Settings.LARGE_FILE_THRESHOLD_MB,
            large_file_threshold_pages=Settings.LARGE_FILE_THRESHOLD_PAGES
        )
        
        # Process document
        chunks = processor.process_document(local_pdf_path, max_pages_per_file)
        
        # Return both chunks and stats
        return {
            'chunks': chunks,
            'stats': processor.extraction_stats,
            'filename': pdf_info['filename'],
            'success': True
        }
        
    except Exception as e:
        print(f"❌ Error processing {pdf_info['filename']}: {e}")
        return {
            'chunks': [],
            'stats': {},
            'filename': pdf_info['filename'],
            'success': False,
            'error': str(e)
        }


# ============================================================================
# MAIN EXECUTION AND ORCHESTRATION FUNCTIONS
# ============================================================================

def process_all_documents(process_all_files: bool = True, max_pages_per_file: int = None, 
                         save_locally: bool = True, use_parallel: bool = False, max_workers: int = 4):
    """Main orchestration function for processing all FDOT documents with intelligent strategies.
    
    This function coordinates the complete document processing pipeline:
    1. Source detection (MinIO vs local storage)
    2. Strategy selection (parallel vs sequential)
    3. Memory-aware batch creation for parallel processing
    4. Progress tracking and error handling
    5. Results aggregation and storage
    
    Features:
    - Automatic slicing for large files
    - Memory-aware parallel processing
    - Comprehensive statistics tracking
    - Graceful fallback handling
    - Detailed progress reporting
    
    Args:
        process_all_files: If False, limits to first 5 files for testing
        max_pages_per_file: Maximum pages to process per file (None for all)
        save_locally: Whether to save results to local JSON files
        use_parallel: Enable parallel processing with multiple workers
        max_workers: Maximum number of parallel workers
        
    Returns:
        bool: Success status of the processing operation
    """
    
    print("=== INTEGRATED FDOT Document Processing (Smart Slicing) ===\n")
    print("🎯 Strategy: Automatic slicing for large files, direct processing for smaller files")
    
    # Show storage configuration
    if save_locally:
        print("💾 Storage: Local files (for quality assessment)")
    else:
        print("⚠️  No storage methods configured")
    
    # Show parallel processing configuration
    if use_parallel:
        print(f"⚡ Parallel processing: {max_workers} workers")
    else:
        print(f"🔄 Sequential processing: 1 worker")
    
    processor = IntegratedFDOTProcessor(
        large_file_threshold_mb=Settings.LARGE_FILE_THRESHOLD_MB,
        large_file_threshold_pages=Settings.LARGE_FILE_THRESHOLD_PAGES
    )
    
    # Get PDF files from MinIO if available, otherwise fall back to local
    if MINIO_AVAILABLE:
        print("📦 Using MinIO for PDF storage")
        try:
            pdf_files_info = pdf_manager.list_pdfs()
            print(f"   📁 Found {len(pdf_files_info)} PDF files in MinIO")
        except Exception as e:
            print(f"⚠️  Error accessing MinIO: {e}")
            print("   🔄 Falling back to local storage")
            pdf_files_info = []
    else:
        print("📁 Using local storage (MinIO not available)")
        pdf_files_info = []
    
    # Fallback to local storage if MinIO is not available or empty
    if not pdf_files_info:
        print("📁 Processing local PDF files...")
        local_pdf_dir = Paths.RAW_PDFS
        if local_pdf_dir.exists():
            pdf_files = list(local_pdf_dir.rglob("*.pdf"))
            print(f"   📁 Found {len(pdf_files)} local PDF files")
        else:
            print("⚠️  No PDF files found in local storage")
            return
    else:
        pdf_files = None  # Will be processed from MinIO
    
    all_chunks = []
    processing_stats = {
        'total_files': 0,
        'total_chunks': 0,
        'by_source': {},
        'extraction_stats': {}
    }
    
    # Process files from MinIO or local storage
    if pdf_files_info:
        # Process MinIO files
        print(f"\n📦 Processing {len(pdf_files_info)} files from MinIO...")
        
        if not process_all_files and len(pdf_files_info) > 5:
            pdf_files_info = pdf_files_info[:5]
            print(f"   🔒 Limited to first 5 files for testing")
        
        source_chunks = []
        
        if use_parallel:
            available_memory_gb = check_memory_available()
            
            # Debug: Check what MinIO provides
            if pdf_files_info:
                print(f"🔍 Debug - First file info keys: {list(pdf_files_info[0].keys())}")
                print(f"🔍 Debug - First file info: {pdf_files_info[0]}")
            
            # Create smart batches based on memory requirements
            batches = create_smart_batches(pdf_files_info, available_memory_gb)
            
            print(f"   📦 Created {len(batches)} smart batches based on memory constraints")
            
            for batch_num, batch in enumerate(batches, 1):
                batch_size_mb = sum(f.get('size', 0) for f in batch) / (1024*1024)
                optimal_workers = get_workers_for_batch(batch, available_memory_gb)
                actual_workers = min(max_workers, optimal_workers)
                
                print(f"   📦 Batch {batch_num}/{len(batches)}: {len(batch)} files, "
                      f"{batch_size_mb:.1f}MB total, {actual_workers} workers")
                
                # Check memory before processing
                current_memory = check_memory_available()
                if current_memory < 2.0:
                    print(f"   ⚠️ Low memory ({current_memory:.1f}GB), waiting for cleanup...")
                    gc.collect()
                    time.sleep(5)
                
                with ProcessPoolExecutor(max_workers=actual_workers) as executor:
                    # Submit batch for processing
                    future_to_pdf = {
                        executor.submit(process_single_pdf, pdf_info, max_pages_per_file): pdf_info 
                        for pdf_info in batch
                    }
                    
                    # Collect results as they complete
                    for future in as_completed(future_to_pdf):
                        pdf_info = future_to_pdf[future]
                        
                        try:
                            result = future.result()
                            if result['success']:
                                file_chunks = result['chunks']
                                source_chunks.extend(file_chunks)
                                
                                # Merge stats from worker
                                if result['stats']:
                                    for key, value in result['stats'].items():
                                        if key in processor.extraction_stats:
                                            processor.extraction_stats[key] += value
                                        else:
                                            processor.extraction_stats[key] = value
                                
                                print(f"   ✅ {result['filename']} → {len(file_chunks)} chunks")
                            else:
                                print(f"   ❌ {result['filename']} failed: {result.get('error', 'Unknown error')}")
                                
                        except Exception as e:
                            print(f"   ❌ {pdf_info['filename']} failed: {e}")
                            continue
                
                # Aggressive cleanup
                gc.collect()
                time.sleep(2)  # Give OS time to reclaim memory
                print(f"   🧹 Batch {batch_num} complete, memory cleaned")
        else:
            # Sequential processing (original method)
            for pdf_info in tqdm(pdf_files_info, desc="  MinIO"):
                start_time = time.time()
                
                try:
                    # Download PDF from MinIO for processing
                    print(f"   📥 Downloading: {pdf_info['filename']}")
                    # Use the object_name (full identifier) for downloading
                    identifier = pdf_info.get('object_name', pdf_info['filename'])
                    local_pdf_path = pdf_manager.download_pdf(identifier, use_cache=True)
                    
                    # Process document (automatic slicing decision)
                    file_chunks = processor.process_document(local_pdf_path, max_pages_per_file)
                    source_chunks.extend(file_chunks)
                    
                    processing_time = time.time() - start_time
                    
                    # Show timing for long processes
                    if processing_time > 30:
                        print(f"   ⏱️  Processing time: {processing_time:.1f} seconds")
                    
                except Exception as e:
                    print(f"   ❌ Error processing {pdf_info['filename']}: {e}")
                    continue
        
        all_chunks.extend(source_chunks)
        processing_stats['by_source']['minio'] = {
            'files': len(pdf_files_info),
            'chunks': len(source_chunks)
        }
        
        print(f"   ✅ {len(pdf_files_info)} files → {len(source_chunks)} chunks")
        
    elif pdf_files:
        # Process local files (fallback)
        print(f"\n📁 Processing {len(pdf_files)} local files...")
        
        if not process_all_files and len(pdf_files) > 5:
            pdf_files = pdf_files[:5]
            print(f"   🔒 Limited to first 5 files for testing")
        
        source_chunks = []
        
        for pdf_file in tqdm(pdf_files, desc="  Local"):
            start_time = time.time()
            
            # Process document (automatic slicing decision)
            file_chunks = processor.process_document(pdf_file, max_pages_per_file)
            processing_time = time.time() - start_time
            source_chunks.extend(file_chunks)
            
            # Show timing for long processes
            if processing_time > 30:
                print(f"   ⏱️  Processing time: {processing_time:.1f} seconds")
        
        all_chunks.extend(source_chunks)
        processing_stats['by_source']['local'] = {
            'files': len(pdf_files),
            'chunks': len(source_chunks)
        }
        
        print(f"   ✅ {len(pdf_files)} files → {len(source_chunks)} chunks")
    
    # Save results
    processing_stats['total_files'] = sum(s['files'] for s in processing_stats['by_source'].values())
    processing_stats['total_chunks'] = len(all_chunks)
    processing_stats['extraction_stats'] = processor.extraction_stats
    
    if all_chunks:
        print(f"\n" + "=" * 20 + " SAVING CHUNKS " + "=" * 20)
        
        # Save locally (for quality assessment)
        if save_locally:
            print(f"💾 Saving chunks locally for quality assessment...")
            output_data = []
            for chunk in all_chunks:
                chunk_data = {
                    "chunk_id": chunk.chunk_id,
                    "content": chunk.content,
                    "metadata": chunk.metadata,
                    "page_number": chunk.page_number,
                    "tables": chunk.tables,
                    "section_info": chunk.section_info
                }
                output_data.append(chunk_data)
            
            # Get output paths from configuration
            output_paths = Paths.get_output_paths(Settings.DEFAULT_OUTPUT_FILENAME)
            output_path = output_paths["chunks"]
            output_path.parent.mkdir(parents=True, exist_ok=True)
            
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(output_data, f, indent=2, ensure_ascii=False)
            
            # Save stats
            stats_path = output_paths["stats"]
            with open(stats_path, 'w', encoding='utf-8') as f:
                json.dump(processing_stats, f, indent=2)
            
            print(f"✅ Local chunks saved to: {output_path}")
        
        # Show storage summary
        if save_locally:
            print(f"💾 Storage: Local files (quality assessment)")
        
        print(f"\n🎉 INTEGRATED Processing Complete!")
        print(f"📊 Total: {processing_stats['total_chunks']:,} chunks from {processing_stats['total_files']} files")
        print(f"📄 Pages processed: {processor.extraction_stats['total_pages_processed']:,}")
        print(f"📝 Text extracted: {processor.extraction_stats['total_text_extracted']:,} characters")
        print(f"📋 Tables extracted: {processor.extraction_stats['total_tables_found']:,}")
        print(f"📈 Avg text per page: {processor.extraction_stats['total_text_extracted'] // max(processor.extraction_stats['total_pages_processed'], 1):,} chars")
        
        # Processing method breakdown
        print(f"\n🔧 Processing Methods Used:")
        print(f"   📖 Direct processing: {processor.extraction_stats['direct_processing_documents']} documents")
        print(f"   🔪 Sliced processing: {processor.extraction_stats['sliced_processing_documents']} documents")
        
        print(f"\n❌ Extraction Issues:")
        print(f"   Text failures: {processor.extraction_stats['text_extraction_failures']}")
        print(f"   Table failures: {processor.extraction_stats['table_extraction_failures']}")
        if OCR_AVAILABLE:
            print(f"   OCR failures: {processor.extraction_stats['ocr_extraction_failures']}")
        
        # ================================================================
        # CHUNK QUALITY ASSESSMENT SUMMARY
        # ================================================================
        print(f"\n" + "=" * 20 + " CHUNK QUALITY ASSESSMENT " + "=" * 20)
        
        # Generate quality summary
        quality_summary = processor._generate_quality_summary(all_chunks)
        
        # Display quality distribution
        print(f"\n📊 Quality Distribution (Total: {quality_summary['total_chunks']} chunks):")
        for quality_class, count in quality_summary['quality_distribution'].items():
            percentage = (count / max(quality_summary['total_chunks'], 1)) * 100
            bar_length = int(percentage / 2)  # Scale to 50 chars max
            bar = "█" * bar_length
            print(f"   {quality_class.capitalize():12} {bar:<50} {count:4d} ({percentage:5.1f}%)")
        
        # Overall quality score
        print(f"\n🎯 Overall Quality Score: {quality_summary['average_quality_score']:.2f}/1.00")
        
        # Dimension breakdown
        print(f"\n📈 Quality Dimensions:")
        for dim, info in quality_summary['dimensions_summary'].items():
            score = info['avg_score']
            status = "✅" if score >= 0.8 else "👍" if score >= 0.7 else "⚠️"
            print(f"   {status} {dim.replace('_', ' ').title():20} {score:.2f}/1.00")
        
        # Quality by content type
        if quality_summary['quality_by_content_type']:
            print(f"\n📑 Quality by Content Type:")
            for content_type, info in quality_summary['quality_by_content_type'].items():
                print(f"   {content_type.replace('_', ' ').title():25} {info['avg_score']:.2f} ({info['chunk_count']} chunks)")
        
        # Quality insights
        if quality_summary['quality_insights']:
            print(f"\n💡 Key Insights:")
            for insight in quality_summary['quality_insights']:
                print(f"   {insight}")
        
        # Reprocessing recommendations
        if quality_summary['chunks_requiring_reprocessing'] > 0:
            percentage = (quality_summary['chunks_requiring_reprocessing'] / quality_summary['total_chunks']) * 100
            print(f"\n⚠️ {quality_summary['chunks_requiring_reprocessing']} chunks ({percentage:.1f}%) flagged for potential reprocessing")
        
        # Save quality summary with stats
        if save_locally:
            # Update stats with quality summary
            processing_stats['quality_summary'] = quality_summary
            
            # Re-save stats with quality information
            with open(stats_path, 'w', encoding='utf-8') as f:
                json.dump(processing_stats, f, indent=2)
        
        print(f"\n💾 Saved to: {output_path}")
        
        # Show breakdown by source
        print(f"\n📋 Breakdown by source:")
        for source_name, stats in processing_stats['by_source'].items():
            chunks_per_file = stats['chunks'] / max(stats['files'], 1)
            print(f"   {source_name}: {stats['files']} files → {stats['chunks']:,} chunks (avg: {chunks_per_file:.0f} chunks/file)")
        
        return True
    
    else:
        print("❌ No chunks created")
        return False


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Process FDOT documents with smart slicing")
    parser.add_argument("--no-local", action="store_true", 
                       help="Skip saving chunks locally")
    parser.add_argument("--max-pages", type=int, default=None,
                       help="Maximum pages to process per file")
    parser.add_argument("--test-mode", action="store_true",
                       help="Process only first 5 files for testing")
    parser.add_argument("--parallel", action="store_true",
                       help="Use parallel processing with multiple workers")
    parser.add_argument("--workers", type=int, default=4,
                       help="Number of parallel workers (default: 4)")
    
    args = parser.parse_args()
    
    # Process all documents with intelligent slicing
    process_all_documents(
        process_all_files=not args.test_mode,   # Process all files unless in test mode
        max_pages_per_file=args.max_pages,      # Limit pages if specified
        save_locally=not args.no_local,         # Save locally unless disabled
        use_parallel=args.parallel,             # Use parallel processing if requested
        max_workers=args.workers                # Number of workers
    )