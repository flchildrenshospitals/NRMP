#!/usr/bin/env python3
"""
Process FDOT PDFs with semantic-aware chunking strategy.
Creates semantic_chunks.json with ~1000 character chunks respecting sentence boundaries.
"""

import sys
from pathlib import Path

# Add backend to path
backend_path = Path(__file__).parent.parent.parent
sys.path.insert(0, str(backend_path))

from app.services.processor import IntegratedFDOTProcessor, Paths
import logging

# Import MinIO support
try:
    from app.utils.pdf_manager import pdf_manager
    MINIO_AVAILABLE = True
except ImportError:
    MINIO_AVAILABLE = False
    pdf_manager = None

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)


def main():
    """Process PDFs with semantic-aware chunking strategy."""
    logger.info("=" * 80)
    logger.info("SEMANTIC-AWARE CHUNKING STRATEGY")
    logger.info("=" * 80)
    logger.info("Strategy: semantic_aware")
    logger.info("Chunk size: ~1000 characters")
    logger.info("Features: Sentence boundary detection, semantic coherence")
    logger.info("=" * 80)

    # Initialize processor with semantic-aware strategy
    processor = IntegratedFDOTProcessor(
        chunk_size=1000,
        chunking_strategy="semantic_aware"
    )

    # Get PDF files from MinIO if available, otherwise fall back to local
    pdf_files_info = []
    if MINIO_AVAILABLE:
        logger.info("📦 Checking MinIO for PDF files...")
        try:
            pdf_files_info = pdf_manager.list_pdfs()
            logger.info(f"Found {len(pdf_files_info)} PDF files in MinIO")
        except Exception as e:
            logger.error(f"Error accessing MinIO: {e}")
            logger.info("Falling back to local storage")

    # Fallback to local storage if MinIO not available or empty
    if not pdf_files_info:
        logger.info("📁 Checking local storage for PDF files...")
        pdf_dir = Paths.RAW_PDFS
        if not pdf_dir.exists():
            logger.error(f"PDF directory not found: {pdf_dir}")
            logger.error("No PDFs available from MinIO or local storage")
            return

        pdf_files = list(pdf_dir.glob("*.pdf"))
        if not pdf_files:
            logger.error(f"No PDF files found in {pdf_dir}")
            return
        
        logger.info(f"Found {len(pdf_files)} local PDF files to process")

        # Process local PDFs
        all_chunks = []
        for pdf_file in pdf_files:
            logger.info(f"\nProcessing: {pdf_file.name}")
            try:
                chunks = processor.process_document(pdf_file)
                all_chunks.extend(chunks)
                logger.info(f"  ✓ Extracted {len(chunks)} chunks")
            except Exception as e:
                logger.error(f"  ✗ Failed to process {pdf_file.name}: {e}")
    else:
        # Process MinIO PDFs
        logger.info(f"\n📦 Processing {len(pdf_files_info)} files from MinIO...")
        all_chunks = []
        for pdf_info in pdf_files_info:
            filename = pdf_info['filename']
            logger.info(f"\nProcessing: {filename}")
            try:
                # Download from MinIO
                identifier = pdf_info.get('object_name', filename)
                local_pdf_path = pdf_manager.download_pdf(identifier, use_cache=True)
                
                # Process document
                chunks = processor.process_document(local_pdf_path)
                all_chunks.extend(chunks)
                logger.info(f"  ✓ Extracted {len(chunks)} chunks")
            except Exception as e:
                logger.error(f"  ✗ Failed to process {filename}: {e}")

    # Convert EnhancedDocumentChunk objects to dictionaries
    output_data = []
    for chunk in all_chunks:
        chunk_data = {
            "chunk_id": chunk.chunk_id,
            "content": chunk.content,
            "metadata": chunk.metadata,
            "page_number": chunk.page_number,
            "tables": chunk.tables,
            "section_info": chunk.section_info
        }
        output_data.append(chunk_data)

    # Save to semantic_chunks.json
    output_file = Paths.PROCESSED_CHUNKS / "semantic_chunks.json"
    output_file.parent.mkdir(parents=True, exist_ok=True)

    import json
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(output_data, f, indent=2, ensure_ascii=False)

    logger.info("=" * 80)
    logger.info(f"✓ Processing complete!")
    logger.info(f"  Total chunks: {len(all_chunks)}")
    logger.info(f"  Output file: {output_file}")
    logger.info(f"  File size: {output_file.stat().st_size / (1024 * 1024):.2f} MB")
    logger.info("=" * 80)


if __name__ == "__main__":
    main()
